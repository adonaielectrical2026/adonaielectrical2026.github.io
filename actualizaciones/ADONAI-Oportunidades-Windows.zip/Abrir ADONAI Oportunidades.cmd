@echo off
start "" "%SystemRoot%\System32\wscript.exe" "%~dp0ADONAI Oportunidades.vbs"
exit /b 0
