Option Explicit

Dim shell, fileSystem, appFolder, powerShellPath, command
Set shell = CreateObject("WScript.Shell")
Set fileSystem = CreateObject("Scripting.FileSystemObject")

appFolder = fileSystem.GetParentFolderName(WScript.ScriptFullName)
powerShellPath = shell.ExpandEnvironmentStrings("%SystemRoot%") & "\System32\WindowsPowerShell\v1.0\powershell.exe"

If Not fileSystem.FileExists(powerShellPath) Then
  MsgBox "No se encontro Windows PowerShell en este equipo.", 16, "ADONAI Oportunidades"
  WScript.Quit 1
End If

command = Chr(34) & powerShellPath & Chr(34) & " -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File " & Chr(34) & appFolder & "\inicio.ps1" & Chr(34)
shell.Run command, 0, False
