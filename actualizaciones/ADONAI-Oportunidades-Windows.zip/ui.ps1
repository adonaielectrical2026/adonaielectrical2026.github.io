﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$script:sourceUrl = 'https://www.comprasestatales.gub.uy/consultas/rss'
$script:sourceSite = 'https://www.comprasestatales.gub.uy/consultas/'
$script:uteUrl = 'https://portal.ute.com.uy/proveedores/compras/licitaciones'
$script:oseUrl = 'https://www.ose.com.uy/compras-y-acreedores/llamados-programas-con-financiamiento-externo'
$script:antelUrl = 'https://antel.com.uy/institucional/compras-y-proveedores'
$script:appVersion = [version]'1.1.0'
$script:updateManifestUrl = 'https://adonaielectrical2026.github.io/actualizaciones/adonai-oportunidades.json'
$script:appDir = Join-Path $env:LOCALAPPDATA 'AdonaiOportunidades'
$script:savedPath = Join-Path $script:appDir 'guardados.json'
$script:allItems = @()
$script:saved = @{}
$script:categories = @(
  @{ Name = 'Instalaciones eléctricas'; Terms = @('instalacion electrica','instalaciones electricas','obra electrica','obras electricas','electrificacion','tendido electrico','cableado electrico','tablero electrico','electricista','servicios electricos') },
  @{ Name = 'Mantenimiento y reparación'; Terms = @('mantenimiento electrico','reparacion electrica','reacondicionamiento electrico','falla electrica','sistema electrico') },
  @{ Name = 'Iluminación'; Terms = @('iluminacion de emergencia','luminaria de emergencia','alumbrado de emergencia','iluminacion','luminarias') },
  @{ Name = 'Cámaras de seguridad'; Terms = @('videovigilancia','camara de seguridad','camaras de seguridad','cctv','circuito cerrado') },
  @{ Name = 'Trámites UTE'; Terms = @('tramite ute','habilitacion electrica','suministro electrico','potencia contratada','conexion electrica') }
)

function Normalize-Text([string]$value) {
  $decomposed = $value.Normalize([System.Text.NormalizationForm]::FormD)
  return ([regex]::Replace($decomposed, '\p{Mn}', '')).ToLowerInvariant()
}

function Get-NodeText($node, [string]$name) {
  $child = $node.SelectSingleNode($name)
  if ($null -eq $child) { return '' }
  return [string]$child.InnerText
}

function Get-Utf8ResponseText($response) {
  # Windows PowerShell 5.1 puede interpretar como Latin-1 una respuesta UTF-8 sin charset.
  $stream = $response.RawContentStream
  if ($null -eq $stream) { throw 'La respuesta no contiene los bytes originales.' }
  if ($stream.CanSeek) { $stream.Position = 0 }
  $reader = [System.IO.StreamReader]::new($stream, [System.Text.Encoding]::UTF8, $true)
  try { return $reader.ReadToEnd().TrimStart([char]0xFEFF) }
  finally { $reader.Dispose() }
}

function Test-TrustedUpdateUrl([string]$value) {
  try {
    $uri = [uri]$value
    return $uri.Scheme -eq 'https' -and $uri.Host -eq 'adonaielectrical2026.github.io'
  } catch { return $false }
}

function Check-ForUpdate {
  $updateButton.Enabled = $false
  $previousText = $updateButton.Text
  $updateButton.Text = 'Buscando…'
  try {
    [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
    $response = Invoke-WebRequest -Uri $script:updateManifestUrl -UserAgent 'ADONAI Oportunidades Updater' -UseBasicParsing -TimeoutSec 20
    $manifest = (Get-Utf8ResponseText $response) | ConvertFrom-Json
    if (-not $manifest.version -or -not $manifest.url -or -not $manifest.sha256) {
      throw 'El archivo de actualización está incompleto.'
    }
    $availableVersion = [version][string]$manifest.version
    if ($availableVersion -le $script:appVersion) {
      [System.Windows.Forms.MessageBox]::Show(
        "Ya tenés la versión más reciente ($($script:appVersion.ToString())).",
        'ADONAI Oportunidades', 'OK', 'Information'
      ) | Out-Null
      return
    }
    if (-not (Test-TrustedUpdateUrl ([string]$manifest.url))) {
      throw 'La descarga no pertenece al sitio oficial de ADONAI ELECTRICAL.'
    }
    $notes = if ($manifest.notes) { "`n`n$([string]$manifest.notes)" } else { '' }
    $answer = [System.Windows.Forms.MessageBox]::Show(
      "Está disponible la versión $availableVersion.$notes`n`n¿Querés descargarla e instalarla ahora?",
      'Actualización disponible', 'YesNo', 'Question'
    )
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { return }

    $updateButton.Text = 'Descargando…'
    New-Item -ItemType Directory -Path $script:appDir -Force | Out-Null
    $updateRoot = Join-Path $script:appDir ('actualizacion-' + [guid]::NewGuid().ToString('N'))
    $packageDir = Join-Path $updateRoot 'paquete'
    $zipPath = Join-Path $updateRoot 'actualizacion.zip'
    New-Item -ItemType Directory -Path $packageDir -Force | Out-Null
    Invoke-WebRequest -Uri ([string]$manifest.url) -UserAgent 'ADONAI Oportunidades Updater' -UseBasicParsing -TimeoutSec 90 -OutFile $zipPath
    $actualHash = (Get-FileHash -Path $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
    $expectedHash = ([string]$manifest.sha256).Trim().ToLowerInvariant()
    if ($actualHash -ne $expectedHash) { throw 'La descarga no superó la verificación de seguridad.' }
    Expand-Archive -Path $zipPath -DestinationPath $packageDir -Force
    foreach ($requiredFile in @('ui.ps1','inicio.ps1','actualizador.ps1','ADONAI Oportunidades.vbs','version.txt')) {
      if (-not (Test-Path (Join-Path $packageDir $requiredFile) -PathType Leaf)) {
        throw "Falta un archivo requerido en la actualización: $requiredFile"
      }
    }

    $updaterPath = Join-Path $PSScriptRoot 'actualizador.ps1'
    $powerShellPath = Join-Path $PSHOME 'powershell.exe'
    $arguments = "-NoProfile -ExecutionPolicy Bypass -STA -File `"$updaterPath`" -PackagePath `"$packageDir`" -InstallPath `"$PSScriptRoot`" -ParentProcessId $PID"
    Start-Process -FilePath $powerShellPath -ArgumentList $arguments
    $form.Close()
  } catch {
    $message = if ($_.Exception.Response -and $_.Exception.Response.StatusCode.value__ -eq 404) {
      'El canal de actualizaciones todavía no está publicado en el sitio de ADONAI ELECTRICAL.'
    } else { $_.Exception.Message }
    [System.Windows.Forms.MessageBox]::Show(
      "No se pudo buscar o instalar la actualización.`n`n$message",
      'ADONAI Oportunidades', 'OK', 'Warning'
    ) | Out-Null
  } finally {
    if (-not $form.IsDisposed) {
      $updateButton.Enabled = $true
      $updateButton.Text = $previousText
    }
  }
}

function Get-Department([string]$value) {
  $text = ' ' + (Normalize-Text $value) + ' '
  $places = [ordered]@{
    'Artigas' = @('artigas','bella union')
    'Canelones' = @('canelones','las piedras','ciudad de la costa','pando','atlantida','santa lucia')
    'Cerro Largo' = @('cerro largo','melo','rio branco')
    'Colonia' = @('colonia','carmelo','nueva helvecia')
    'Durazno' = @('durazno','sarandi del yi')
    'Flores' = @('flores','trinidad')
    'Florida' = @('florida','sarandi grande')
    'Lavalleja' = @('lavalleja')
    'Maldonado' = @('maldonado','punta del este','piriapolis')
    'Montevideo' = @('montevideo')
    'Paysandú' = @('paysandu')
    'Río Negro' = @('rio negro','fray bentos','young')
    'Rivera' = @('rivera','tranqueras')
    'Rocha' = @('rocha','chuy','lascano')
    'Salto' = @('salto')
    'San José' = @('san jose','ciudad del plata')
    'Soriano' = @('soriano','mercedes','dolores')
    'Tacuarembó' = @('tacuarembo','paso de los toros')
    'Treinta y Tres' = @('treinta y tres','vergara')
  }
  foreach ($department in $places.Keys) {
    foreach ($place in $places[$department]) {
      if ($text.Contains(' ' + $place + ' ')) { return $department }
    }
  }
  foreach ($marker in @('pereira rossell','planta de portland manga','18 de julio 1670','cerrito1034','cerrito 1034','paraguay 2097')) {
    if ($text.Contains($marker)) { return 'Montevideo' }
  }
  return ''
}

function Get-Categories([string]$content) {
  $text = Normalize-Text $content
  $categoryMatches = @()
  foreach ($category in $script:categories) {
    foreach ($term in $category.Terms) {
      if ($text.Contains($term)) { $categoryMatches += $category.Name; break }
    }
  }
  return $categoryMatches
}

function Parse-Feed([string]$content) {
  [xml]$xml = $content
  $records = @()
  foreach ($entry in @($xml.SelectNodes('//item'))) {
    $parts = (Get-NodeText $entry 'title') -split '\|', 2
    $title = $parts[0].Trim()
    $buyer = if ($parts.Count -gt 1) { $parts[1].Trim() } else { '' }
    $link = (Get-NodeText $entry 'link').Trim()
    if ($link -notmatch '^https?://(www\.)?comprasestatales\.gub\.uy/') { continue }
    $link = $link -replace '^http:', 'https:'
    $raw = [System.Net.WebUtility]::HtmlDecode((Get-NodeText $entry 'description'))
    $description = [regex]::Replace($raw, '<[^>]*>', ' ')
    $description = [regex]::Replace($description, '\s+', ' ').Trim()
    $closing = $null
    $deadline = [regex]::Match($description, 'Recepci[oó]n de ofertas hasta:\s*(\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2})\s*hs', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    if ($deadline.Success) {
      try { $closing = [datetime]::ParseExact($deadline.Groups[1].Value, 'dd/MM/yyyy HH:mm', [System.Globalization.CultureInfo]::InvariantCulture) } catch { }
      $description = $description.Substring(0, $deadline.Index).Trim()
    }
    $published = $null
    $pubText = (Get-NodeText $entry 'pubDate') -replace '\s+\([^)]+\)$', ''
    try { $published = [datetimeoffset]::Parse($pubText, [System.Globalization.CultureInfo]::InvariantCulture).LocalDateTime } catch { }
    $records += [pscustomobject]@{
      Id = $link; Title = $title; Buyer = $buyer; Description = $description
      Department = (Get-Department "$title $description $buyer"); Closing = $closing
      Published = $published; Link = $link; Source = 'ARCE'; Categories = @(Get-Categories "$title $description")
    }
  }
  return $records
}

function Strip-Html([string]$value) {
  $text = [regex]::Replace($value, '<[^>]*>', ' ')
  return [regex]::Replace([System.Net.WebUtility]::HtmlDecode($text), '\s+', ' ').Trim()
}

function Get-RelevantDetailText([string]$html) {
  $text = Strip-Html $html
  $start = $text.IndexOf('Consulta de Publicaciones')
  if ($start -ge 0) { $text = $text.Substring($start) }
  $end = $text.Length
  foreach ($marker in @('Información de contacto:', 'Ítems del llamado', 'Agencia Reguladora de Compras Estatales')) {
    $position = $text.IndexOf($marker)
    if ($position -gt 0 -and $position -lt $end) { $end = $position }
  }
  return $text.Substring(0, $end)
}

function Complete-MissingDepartments([object[]]$records) {
  $pending = @($records | Where-Object { $_.Source -eq 'ARCE' -and $_.Categories.Count -and -not $_.Department } | Select-Object -First 25)
  $position = 0
  foreach ($item in $pending) {
    $position++
    $script:statusLabel.Text = "Completando zonas desde ARCE ($position/$($pending.Count))…"
    [System.Windows.Forms.Application]::DoEvents()
    try {
      $response = Invoke-WebRequest -Uri $item.Link -UserAgent 'Mozilla/5.0 (ADONAI Oportunidades)' -UseBasicParsing -TimeoutSec 12
      $detailText = Get-RelevantDetailText (Get-Utf8ResponseText $response)
      $department = Get-Department "$($item.Title) $($item.Buyer) $($item.Description) $detailText"
      if ($department) { $item.Department = $department }
    } catch { }
  }
}

function Resolve-OfficialLink([string]$base, [string]$rowHtml) {
  $hrefMatches = [regex]::Matches($rowHtml, 'href\s*=\s*["'']([^"'']+)["'']', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
  foreach ($match in $hrefMatches) {
    try {
      $url = [uri]::new([uri]$base, [System.Net.WebUtility]::HtmlDecode($match.Groups[1].Value))
      if ($url.Scheme -eq 'https' -and ($url.Host -match '(^|\.)(gub\.uy|ute\.com\.uy|ose\.com\.uy)$')) { return $url.AbsoluteUri }
    } catch { }
  }
  return $base
}

function Parse-DirectTable([string]$content, [string]$base, [string]$sourceName) {
  $records = @()
  $rows = [regex]::Matches($content, '<tr\b[^>]*>(.*?)</tr>', [System.Text.RegularExpressions.RegexOptions]::Singleline -bor [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
  foreach ($row in $rows) {
    $cells = @([regex]::Matches($row.Groups[1].Value, '<t[dh]\b[^>]*>(.*?)</t[dh]>', [System.Text.RegularExpressions.RegexOptions]::Singleline -bor [System.Text.RegularExpressions.RegexOptions]::IgnoreCase) | ForEach-Object { Strip-Html $_.Groups[1].Value })
    if ($cells.Count -lt 4) { continue }
    if ($sourceName -eq 'UTE') {
      $reference = $cells[0]; $title = $cells[1]; $dateText = $cells[3]
      if ($reference -eq 'DATA ROOM' -or $reference -match '^LICITACI') { continue }
      $buyer = 'UTE'; $published = $null
    } else {
      $reference = $cells[0]; $title = $cells[1]; $dateText = $cells[3]
      $buyer = 'OSE'
      $published = $null
      try { $published = [datetime]::ParseExact($reference, 'dd/MM/yyyy', [System.Globalization.CultureInfo]::InvariantCulture) } catch { }
      if ($cells.Count -gt 4 -and $cells[4] -match 'Finalizado') { continue }
    }
    if ([string]::IsNullOrWhiteSpace($title)) { continue }
    $dateMatch = [regex]::Match($dateText, '(\d{2}/\d{2}/\d{4})(?:\s+(\d{2}:\d{2}))?')
    $closing = $null
    if ($dateMatch.Success) {
      $format = if ($dateMatch.Groups[2].Success) { 'dd/MM/yyyy HH:mm' } else { 'dd/MM/yyyy' }
      $value = if ($dateMatch.Groups[2].Success) { "$($dateMatch.Groups[1].Value) $($dateMatch.Groups[2].Value)" } else { $dateMatch.Groups[1].Value }
      try { $closing = [datetime]::ParseExact($value, $format, [System.Globalization.CultureInfo]::InvariantCulture) } catch { }
    }
    $link = Resolve-OfficialLink $base $row.Groups[1].Value
    $records += [pscustomobject]@{
      Id = "$sourceName|$reference|$title"; Title = "$reference - $title"; Buyer = $buyer
      Description = $title; Department = (Get-Department $title); Closing = $closing
      Published = $published; Link = $link; Source = $sourceName; Categories = @(Get-Categories $title)
    }
  }
  return $records
}

function Load-Saved {
  if (Test-Path $script:savedPath) {
    try {
      $values = @(Get-Content $script:savedPath -Raw | ConvertFrom-Json)
      foreach ($value in $values) { $script:saved[[string]$value] = $true }
    } catch { }
  }
}

function Save-Saved {
  New-Item -ItemType Directory -Path $script:appDir -Force | Out-Null
  @($script:saved.Keys) | ConvertTo-Json | Set-Content -Path $script:savedPath -Encoding UTF8
}

function New-Label([string]$text, [int]$x, [int]$y, [int]$width, [int]$height, [int]$size = 9, [bool]$bold = $false) {
  $label = New-Object System.Windows.Forms.Label
  $label.Text = $text; $label.Location = [System.Drawing.Point]::new($x, $y)
  $label.Size = [System.Drawing.Size]::new($width, $height)
  $style = if ($bold) { [System.Drawing.FontStyle]::Bold } else { [System.Drawing.FontStyle]::Regular }
  $label.Font = [System.Drawing.Font]::new('Segoe UI', $size, $style)
  return $label
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'ADONAI ELECTRICAL · Oportunidades'
$form.Size = [System.Drawing.Size]::new(1220, 790)
$form.MinimumSize = [System.Drawing.Size]::new(970, 640)
$form.StartPosition = 'CenterScreen'
$form.BackColor = [System.Drawing.Color]::FromArgb(245, 247, 250)
$form.Font = [System.Drawing.Font]::new('Segoe UI', 9)

$root = New-Object System.Windows.Forms.TableLayoutPanel
$root.Dock = 'Fill'; $root.Margin = [System.Windows.Forms.Padding]::Empty
$root.Padding = [System.Windows.Forms.Padding]::Empty
$root.ColumnCount = 1; $root.RowCount = 3
[void]$root.ColumnStyles.Add([System.Windows.Forms.ColumnStyle]::new([System.Windows.Forms.SizeType]::Percent, 100))
[void]$root.RowStyles.Add([System.Windows.Forms.RowStyle]::new([System.Windows.Forms.SizeType]::Absolute, 94))
[void]$root.RowStyles.Add([System.Windows.Forms.RowStyle]::new([System.Windows.Forms.SizeType]::Percent, 100))
[void]$root.RowStyles.Add([System.Windows.Forms.RowStyle]::new([System.Windows.Forms.SizeType]::Absolute, 24))
$form.Controls.Add($root)

$body = New-Object System.Windows.Forms.TableLayoutPanel
$body.Dock = 'Fill'; $body.Margin = [System.Windows.Forms.Padding]::Empty
$body.Padding = [System.Windows.Forms.Padding]::Empty
$body.ColumnCount = 2; $body.RowCount = 1
[void]$body.ColumnStyles.Add([System.Windows.Forms.ColumnStyle]::new([System.Windows.Forms.SizeType]::Absolute, 250))
[void]$body.ColumnStyles.Add([System.Windows.Forms.ColumnStyle]::new([System.Windows.Forms.SizeType]::Percent, 100))
[void]$body.RowStyles.Add([System.Windows.Forms.RowStyle]::new([System.Windows.Forms.SizeType]::Percent, 100))
$root.Controls.Add($body, 0, 1)

$header = New-Object System.Windows.Forms.Panel
$header.Dock = 'Fill'; $header.Margin = [System.Windows.Forms.Padding]::Empty
$header.BackColor = [System.Drawing.Color]::FromArgb(16, 26, 43)
$headerTitle = New-Label 'ADONAI ELECTRICAL' 24 15 500 27 15 $true
$headerTitle.ForeColor = [System.Drawing.Color]::White
$headerSubtitle = New-Label 'Oportunidades de compras públicas · Uruguay' 25 49 600 22 9
$headerSubtitle.ForeColor = [System.Drawing.Color]::FromArgb(187, 198, 214)
$header.Controls.AddRange(@($headerTitle,$headerSubtitle))
$updatePanel = New-Object System.Windows.Forms.Panel
$updatePanel.Dock = 'Right'; $updatePanel.Width = 235
$versionLabel = New-Label "Versión $($script:appVersion.ToString())" 14 10 205 21 8
$versionLabel.ForeColor = [System.Drawing.Color]::FromArgb(187, 198, 214)
$updateButton = New-Object System.Windows.Forms.Button
$updateButton.Text = 'Buscar actualizaciones'
$updateButton.Location = [System.Drawing.Point]::new(14, 37)
$updateButton.Size = [System.Drawing.Size]::new(200, 34)
$updateButton.FlatStyle = 'Flat'
$updateButton.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(95, 116, 145)
$updateButton.BackColor = [System.Drawing.Color]::FromArgb(28, 45, 70)
$updateButton.UseVisualStyleBackColor = $false
$updateButton.ForeColor = [System.Drawing.Color]::White
$updatePanel.Controls.AddRange(@($versionLabel,$updateButton))
$header.Controls.Add($updatePanel)
$root.Controls.Add($header, 0, 0)

$footer = New-Object System.Windows.Forms.StatusStrip
$footer.Dock = 'Fill'; $footer.Margin = [System.Windows.Forms.Padding]::Empty
$footer.BackColor = [System.Drawing.Color]::FromArgb(232, 236, 242)
$script:statusLabel = New-Object System.Windows.Forms.ToolStripStatusLabel
$script:statusLabel.Text = 'Preparando consulta de ARCE…'
$footer.Items.Add($script:statusLabel) | Out-Null
$root.Controls.Add($footer, 0, 2)

$sidebar = New-Object System.Windows.Forms.Panel
$sidebar.Dock = 'Fill'; $sidebar.Margin = [System.Windows.Forms.Padding]::Empty
$sidebar.Padding = [System.Windows.Forms.Padding]::new(14)
$sidebar.BackColor = [System.Drawing.Color]::White
$body.Controls.Add($sidebar, 0, 0)
$sidebarTitle = New-Label 'FILTROS' 18 22 200 25 10 $true
$sidebar.Controls.Add($sidebarTitle)
$sidebar.Controls.Add((New-Label 'Buscar' 18 66 210 20 9 $true))
$search = New-Object System.Windows.Forms.TextBox
$search.Location = [System.Drawing.Point]::new(18, 90); $search.Size = [System.Drawing.Size]::new(212, 28)
$sidebar.Controls.Add($search)
$sidebar.Controls.Add((New-Label 'Zona' 18 141 210 20 9 $true))
$zone = New-Object System.Windows.Forms.ComboBox
$zone.DropDownStyle = 'DropDownList'; $zone.Location = [System.Drawing.Point]::new(18, 165)
$zone.Size = [System.Drawing.Size]::new(212, 28)
@('Todo Uruguay','Salto','Litoral norte') | ForEach-Object { [void]$zone.Items.Add($_) }
$zone.SelectedIndex = 0; $sidebar.Controls.Add($zone)
$sidebar.Controls.Add((New-Label 'Estado' 18 216 210 20 9 $true))
$state = New-Object System.Windows.Forms.ComboBox
$state.DropDownStyle = 'DropDownList'; $state.Location = [System.Drawing.Point]::new(18, 240)
$state.Size = [System.Drawing.Size]::new(212, 28)
@('Abiertos para ofertar','Todos los publicados','Sin fecha de cierre') | ForEach-Object { [void]$state.Items.Add($_) }
$state.SelectedIndex = 1; $sidebar.Controls.Add($state)
$sidebar.Controls.Add((New-Label 'Fuente' 18 294 210 20 9 $true))
$sourceFilter = New-Object System.Windows.Forms.ComboBox
$sourceFilter.DropDownStyle = 'DropDownList'; $sourceFilter.Location = [System.Drawing.Point]::new(18, 318)
$sourceFilter.Size = [System.Drawing.Size]::new(212, 28)
@('Todas las fuentes','ARCE','UTE','OSE') | ForEach-Object { [void]$sourceFilter.Items.Add($_) }
$sourceFilter.SelectedIndex = 0; $sidebar.Controls.Add($sourceFilter)
$sidebar.Controls.Add((New-Label 'Servicios' 18 365 210 20 9 $true))
$services = New-Object System.Windows.Forms.CheckedListBox
$services.Location = [System.Drawing.Point]::new(18, 389); $services.Size = [System.Drawing.Size]::new(212, 154)
$services.BorderStyle = 'None'; $services.CheckOnClick = $true
foreach ($category in $script:categories) { [void]$services.Items.Add($category.Name, $true) }
$sidebar.Controls.Add($services)
$main = New-Object System.Windows.Forms.Panel
$main.Dock = 'Fill'; $main.Margin = [System.Windows.Forms.Padding]::Empty
$main.Padding = [System.Windows.Forms.Padding]::new(20)
$body.Controls.Add($main, 1, 0)
$pageTitle = New-Label 'Llamados relevantes' 22 17 600 38 16 $true
$main.Controls.Add($pageTitle)
$script:summary = New-Label 'Consultando ARCE…' 24 56 650 23 9
$script:summary.ForeColor = [System.Drawing.Color]::FromArgb(105, 119, 138)
$main.Controls.Add($script:summary)
$refresh = New-Object System.Windows.Forms.Button
$refresh.Text = 'Actualizar'; $refresh.Size = New-Object System.Drawing.Size(110, 32)
$refresh.Anchor = 'Top,Right'; $refresh.Location = [System.Drawing.Point]::new(790, 26)
$main.Controls.Add($refresh)
$onlySaved = New-Object System.Windows.Forms.CheckBox
$onlySaved.Text = 'Solo guardados'; $onlySaved.AutoSize = $true
$onlySaved.Location = [System.Drawing.Point]::new(24, 88)
$main.Controls.Add($onlySaved)
$list = New-Object System.Windows.Forms.ListView
$list.View = 'Details'; $list.FullRowSelect = $true; $list.MultiSelect = $false
$list.HideSelection = $false; $list.Location = [System.Drawing.Point]::new(22, 122)
$list.Size = [System.Drawing.Size]::new(880, 330)
$list.Anchor = 'Top,Left,Right,Bottom'
[void]$list.Columns.Add('Llamado', 335)
[void]$list.Columns.Add('Organismo', 180)
[void]$list.Columns.Add('Cierre', 110)
[void]$list.Columns.Add('Zona', 90)
[void]$list.Columns.Add('Fuente', 70)
$main.Controls.Add($list)

$detail = New-Object System.Windows.Forms.Panel
$detail.Location = [System.Drawing.Point]::new(22, 465)
$detail.Size = [System.Drawing.Size]::new(880, 220)
$detail.Anchor = 'Left,Right,Bottom'
$detail.BackColor = [System.Drawing.Color]::White
$main.Controls.Add($detail)
$script:detailTitle = New-Label 'Seleccioná un llamado para ver sus detalles' 17 12 700 31 12 $true
$script:detailTitle.Anchor = 'Top,Left,Right'; $detail.Controls.Add($script:detailTitle)
$script:detailInfo = New-Label '' 18 46 700 20 9
$script:detailInfo.ForeColor = [System.Drawing.Color]::FromArgb(85, 99, 118)
$detail.Controls.Add($script:detailInfo)
$script:detailDescription = New-Object System.Windows.Forms.TextBox
$script:detailDescription.Multiline = $true; $script:detailDescription.ReadOnly = $true
$script:detailDescription.ScrollBars = 'Vertical'; $script:detailDescription.BorderStyle = 'None'
$script:detailDescription.Location = [System.Drawing.Point]::new(18, 75)
$script:detailDescription.Size = [System.Drawing.Size]::new(830, 83)
$script:detailDescription.Anchor = 'Top,Left,Right'; $detail.Controls.Add($script:detailDescription)
$open = New-Object System.Windows.Forms.Button
$open.Text = 'Ver llamado oficial'; $open.Location = [System.Drawing.Point]::new(18, 173)
$open.Size = [System.Drawing.Size]::new(160, 31); $open.Enabled = $false
$detail.Controls.Add($open)
$save = New-Object System.Windows.Forms.Button
$save.Text = 'Guardar'; $save.Location = [System.Drawing.Point]::new(188, 173)
$save.Size = [System.Drawing.Size]::new(100, 31); $save.Enabled = $false
$detail.Controls.Add($save)
$portals = New-Object System.Windows.Forms.Button
$portals.Text = 'Portales oficiales ▾'; $portals.Location = [System.Drawing.Point]::new(305, 173)
$portals.Size = [System.Drawing.Size]::new(155, 31); $detail.Controls.Add($portals)
$portalMenu = New-Object System.Windows.Forms.ContextMenuStrip
foreach ($portal in @(
  @{ Name = 'ARCE · Estado y gobiernos departamentales'; Url = $script:sourceSite },
  @{ Name = 'UTE · Licitaciones'; Url = $script:uteUrl },
  @{ Name = 'ANTEL · Compras y proveedores'; Url = $script:antelUrl },
  @{ Name = 'OSE · Licitaciones'; Url = 'https://www.ose.com.uy/compras-y-acreedores/licitaciones-y-compras' },
  @{ Name = 'OSE · Programas especiales'; Url = $script:oseUrl }
)) {
  $menuItem = [System.Windows.Forms.ToolStripMenuItem]::new($portal.Name)
  $menuItem.Tag = $portal.Url
  $menuItem.Add_Click({ Start-Process $this.Tag })
  [void]$portalMenu.Items.Add($menuItem)
}

function Update-Details {
  if ($list.SelectedItems.Count -eq 0) {
    $script:detailTitle.Text = 'Seleccioná un llamado para ver sus detalles'
    $script:detailInfo.Text = ''; $script:detailDescription.Text = ''
    $open.Enabled = $false; $save.Enabled = $false
    return
  }
  $item = $list.SelectedItems[0].Tag
  $script:detailTitle.Text = $item.Title
  $closing = if ($item.Closing) { $item.Closing.ToString('dd/MM/yyyy HH:mm') } else { 'No informada' }
  $department = if ($item.Department) { $item.Department } else { 'Consultar pliego' }
  $script:detailInfo.Text = "Fuente: $($item.Source)   ·   Organismo: $($item.Buyer)   ·   Zona: $department   ·   Cierre: $closing"
  $script:detailDescription.Text = $item.Description
  $save.Text = if ($script:saved.ContainsKey($item.Id)) { '★ Guardado' } else { '☆ Guardar' }
  $open.Enabled = $true; $save.Enabled = $true
}

function Apply-Filters {
  $list.BeginUpdate(); $list.Items.Clear()
  $queryWords = @((Normalize-Text $search.Text).Split(' ', [System.StringSplitOptions]::RemoveEmptyEntries))
  $checked = @(); foreach ($category in $services.CheckedItems) { $checked += [string]$category }
  $today = [datetime]::Now
  $visible = @()
  foreach ($item in $script:allItems) {
    if ($onlySaved.Checked -and -not $script:saved.ContainsKey($item.Id)) { continue }
    if ($sourceFilter.SelectedIndex -gt 0 -and $item.Source -ne $sourceFilter.Text) { continue }
    $matchingCategory = $false
    foreach ($category in $item.Categories) {
      if ($checked -contains $category) { $matchingCategory = $true; break }
    }
    if (-not $matchingCategory) { continue }
    $searchText = Normalize-Text "$($item.Title) $($item.Description) $($item.Buyer)"
    $matchesQuery = $true
    foreach ($word in $queryWords) {
      if (-not $searchText.Contains($word)) { $matchesQuery = $false; break }
    }
    if (-not $matchesQuery) { continue }
    if ($zone.SelectedIndex -eq 1 -and $item.Department -ne 'Salto') { continue }
    if ($zone.SelectedIndex -eq 2 -and @('Salto','Artigas','Paysandú','Río Negro') -notcontains $item.Department) { continue }
    if ($state.SelectedIndex -eq 0 -and (-not $item.Closing -or $item.Closing -lt $today)) { continue }
    if ($state.SelectedIndex -eq 2 -and $item.Closing) { continue }
    $visible += $item
  }
  $visible = @($visible | Sort-Object -Property @{ Expression = { if ($_.Closing) { $_.Closing } else { [datetime]::MaxValue } } })
  foreach ($item in $visible) {
    $label = if ($script:saved.ContainsKey($item.Id)) { '★ ' + $item.Title } else { $item.Title }
    $row = New-Object System.Windows.Forms.ListViewItem($label)
    [void]$row.SubItems.Add($item.Buyer)
    [void]$row.SubItems.Add($(if ($item.Closing) { $item.Closing.ToString('dd/MM/yyyy HH:mm') } else { 'No informada' }))
    [void]$row.SubItems.Add($(if ($item.Department) { $item.Department } else { 'Consultar pliego' }))
    [void]$row.SubItems.Add($item.Source)
    $row.Tag = $item
    [void]$list.Items.Add($row)
  }
  $list.EndUpdate()
  $script:summary.Text = "$($visible.Count) coincidencias · $($script:allItems.Count) publicaciones recientes revisadas"
  Update-Details
}

function Update-Layout {
  $contentWidth = [Math]::Max(500, $main.ClientSize.Width - 44)
  $detailTop = [Math]::Max(260, $main.ClientSize.Height - 235)
  $list.Size = [System.Drawing.Size]::new($contentWidth, [Math]::Max(100, $detailTop - 136))
  $detail.Location = [System.Drawing.Point]::new(22, $detailTop)
  $detail.Size = [System.Drawing.Size]::new($contentWidth, 220)
  $refresh.Location = [System.Drawing.Point]::new([Math]::Max(250, $main.ClientSize.Width - 132), 26)
}

function Refresh-Data {
  $refresh.Enabled = $false; $form.UseWaitCursor = $true
  $script:statusLabel.Text = 'Consultando ARCE, UTE y OSE…'
  [System.Windows.Forms.Application]::DoEvents()
  $loaded = @()
  $failures = @()
  $sourceCounts = @{ ARCE = 0; UTE = 0; OSE = 0 }
  try {
    $response = Invoke-WebRequest -Uri $script:sourceUrl -UserAgent 'Mozilla/5.0 (ADONAI Oportunidades)' -UseBasicParsing -TimeoutSec 25
    $records = @(Parse-Feed (Get-Utf8ResponseText $response))
    $sourceCounts['ARCE'] = $records.Count
    if (-not $records.Count) { $failures += 'ARCE (sin publicaciones legibles)' }
    $loaded += $records
  } catch {
    $failures += 'ARCE'
  }
  foreach ($feed in @(@{ Name = 'UTE'; Url = $script:uteUrl }, @{ Name = 'OSE'; Url = $script:oseUrl })) {
    try {
      $script:statusLabel.Text = "Consultando $($feed.Name)…"
      [System.Windows.Forms.Application]::DoEvents()
      $response = Invoke-WebRequest -Uri $feed.Url -UserAgent 'Mozilla/5.0 (ADONAI Oportunidades)' -UseBasicParsing -TimeoutSec 20
      $records = @(Parse-DirectTable (Get-Utf8ResponseText $response) $feed.Url $feed.Name)
      $sourceCounts[$feed.Name] = $records.Count
      $loaded += $records
    } catch { $failures += $feed.Name }
  }
  Complete-MissingDepartments $loaded
  $script:allItems = @($loaded | Sort-Object -Property Id -Unique)
  Apply-Filters
  $countText = "ARCE $($sourceCounts['ARCE']) · UTE $($sourceCounts['UTE']) · OSE $($sourceCounts['OSE'])"
  if ($failures.Count) {
    $script:statusLabel.Text = "Actualización parcial · $countText · Sin acceso a: $($failures -join ', ')"
  } else {
    $script:statusLabel.Text = "Publicaciones leídas: $countText · $(Get-Date -Format 'dd/MM/yyyy HH:mm')"
  }
  if (-not $script:allItems.Count) {
    [System.Windows.Forms.MessageBox]::Show('No se pudieron cargar llamados de las fuentes oficiales. Revisá tu conexión o abrí sus portales directamente.', 'ADONAI Oportunidades', 'OK', 'Warning') | Out-Null
  }
  $refresh.Enabled = $true; $form.UseWaitCursor = $false
}

$search.Add_TextChanged({ Apply-Filters })
$zone.Add_SelectedIndexChanged({ Apply-Filters })
$state.Add_SelectedIndexChanged({ Apply-Filters })
$sourceFilter.Add_SelectedIndexChanged({ Apply-Filters })
$services.Add_ItemCheck({ $form.BeginInvoke([Action]{ Apply-Filters }) | Out-Null })
$onlySaved.Add_CheckedChanged({ Apply-Filters })
$list.Add_SelectedIndexChanged({ Update-Details })
$refresh.Add_Click({ Refresh-Data })
$updateButton.Add_Click({ Check-ForUpdate })
$open.Add_Click({ if ($list.SelectedItems.Count) { Start-Process $list.SelectedItems[0].Tag.Link } })
$portals.Add_Click({ $portalMenu.Show($portals, [System.Drawing.Point]::new(0, $portals.Height)) })
$save.Add_Click({
  if (-not $list.SelectedItems.Count) { return }
  $id = $list.SelectedItems[0].Tag.Id
  if ($script:saved.ContainsKey($id)) { $script:saved.Remove($id) } else { $script:saved[$id] = $true }
  Save-Saved; Apply-Filters
})
$form.Add_Shown({
  $updateMarker = Join-Path $script:appDir 'actualizacion-ok.txt'
  if (Test-Path $updateMarker -PathType Leaf) {
    Remove-Item -LiteralPath $updateMarker -Force -ErrorAction SilentlyContinue
    [System.Windows.Forms.MessageBox]::Show(
      "La actualización se instaló correctamente.`n`nVersión $($script:appVersion.ToString())",
      'ADONAI Oportunidades', 'OK', 'Information'
    ) | Out-Null
  }
  Refresh-Data
})
$main.Add_Resize({ Update-Layout })
Load-Saved
[void]$form.PerformLayout()
Update-Layout
[void]$form.ShowDialog()
