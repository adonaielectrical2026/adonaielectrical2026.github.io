@echo off
setlocal
set "LOG_PATH=%LOCALAPPDATA%\AdonaiOportunidades\error.log"
if not exist "%LOG_PATH%" (
  echo Aun no se genero un registro de errores.
  echo Si el programa falla al abrir, el registro aparecera aqui:
  echo %LOG_PATH%
  pause
  exit /b 0
)
start "" notepad.exe "%LOG_PATH%"
