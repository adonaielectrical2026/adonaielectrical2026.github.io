﻿param(
  [Parameter(Mandatory = $true)][string]$PackagePath,
  [Parameter(Mandatory = $true)][string]$InstallPath,
  [Parameter(Mandatory = $true)][int]$ParentProcessId
)

$ErrorActionPreference = 'Stop'
$localData = [Environment]::GetFolderPath('LocalApplicationData')
if ([string]::IsNullOrWhiteSpace($localData)) { $localData = $env:LOCALAPPDATA }
if ([string]::IsNullOrWhiteSpace($localData)) { $localData = $env:TEMP }
if ([string]::IsNullOrWhiteSpace($localData)) { throw 'Windows no informó una carpeta local para completar la actualización.' }
$appDataDir = Join-Path $localData 'AdonaiOportunidades'
$logPath = Join-Path $appDataDir 'actualizacion-error.log'
$backupDir = $null
$replacedFiles = @()
$createdFiles = @()

try {
  Wait-Process -Id $ParentProcessId -Timeout 30 -ErrorAction SilentlyContinue
  New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null
  New-Item -ItemType Directory -Path $appDataDir -Force | Out-Null
  $backupDir = Join-Path $appDataDir ('respaldo-' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
  $files = @(
    'ui.ps1',
    'inicio.ps1',
    'actualizador.ps1',
    'motor.ps1',
    'informe-diario.ps1',
    'Abrir ADONAI Oportunidades.cmd',
    'Abrir con diagnostico.cmd',
    'ADONAI Oportunidades.ico',
    'Ver registro de errores.cmd',
    'LEEME.txt',
    'FUENTES.txt',
    'version.txt'
  )
  foreach ($name in $files) {
    $source = Join-Path $PackagePath $name
    if (Test-Path $source -PathType Leaf) {
      $destination = Join-Path $InstallPath $name
      if (Test-Path $destination -PathType Leaf) {
        Copy-Item -LiteralPath $destination -Destination (Join-Path $backupDir $name) -Force
        $replacedFiles += $name
      } else {
        $createdFiles += $name
      }
      Copy-Item -LiteralPath $source -Destination $destination -Force
    }
  }
  Set-Content -Path (Join-Path $appDataDir 'actualizacion-ok.txt') -Value (Get-Date -Format 'dd/MM/yyyy HH:mm') -Encoding UTF8
  $powerShellPath = Join-Path $PSHOME 'powershell.exe'
  $startScript = Join-Path $InstallPath 'inicio.ps1'
  $arguments = "-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File `"$startScript`""
  Start-Process -FilePath $powerShellPath -ArgumentList $arguments
  $updateRoot = Split-Path $PackagePath -Parent
  Start-Sleep -Milliseconds 500
  Remove-Item -LiteralPath $updateRoot -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath $backupDir -Recurse -Force -ErrorAction SilentlyContinue
} catch {
  New-Item -ItemType Directory -Path $appDataDir -Force | Out-Null
  if ($backupDir -and (Test-Path $backupDir -PathType Container)) {
    foreach ($name in $replacedFiles) {
      $backupFile = Join-Path $backupDir $name
      if (Test-Path $backupFile -PathType Leaf) {
        Copy-Item -LiteralPath $backupFile -Destination (Join-Path $InstallPath $name) -Force -ErrorAction SilentlyContinue
      }
    }
    foreach ($name in $createdFiles) {
      Remove-Item -LiteralPath (Join-Path $InstallPath $name) -Force -ErrorAction SilentlyContinue
    }
  }
  ($_ | Format-List * -Force | Out-String) | Set-Content -Path $logPath -Encoding UTF8
  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.MessageBox]::Show(
    "No se pudo instalar la actualización.`n`n$($_.Exception.Message)`n`nDetalles: $logPath",
    'ADONAI Oportunidades', 'OK', 'Error'
  ) | Out-Null
}
