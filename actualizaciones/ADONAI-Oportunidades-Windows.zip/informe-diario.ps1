﻿$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'motor.ps1')

function Write-ReportLog([string]$message) {
  New-Item -ItemType Directory -Path $script:AdonaiAppDir -Force | Out-Null
  $line = "$(Get-Date -Format 'dd/MM/yyyy HH:mm:ss') · $message"
  Add-Content -LiteralPath (Join-Path $script:AdonaiAppDir 'informe-diario.log') -Value $line -Encoding UTF8
}

function Show-AdonaiNotification([string]$title, [string]$message) {
  try {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $notification = New-Object System.Windows.Forms.NotifyIcon
    $notification.Icon = [System.Drawing.SystemIcons]::Information
    $notification.BalloonTipTitle = $title
    $notification.BalloonTipText = $message
    $notification.Visible = $true
    $notification.ShowBalloonTip(7000)
    Start-Sleep -Seconds 8
    $notification.Dispose()
  } catch { }
}

try {
  $config = Get-AdonaiConfig
  if (-not [bool]$config.Email.Enabled) { Write-ReportLog 'Envío desactivado.'; exit 0 }
  $data = Get-AdonaiData $config $null $true
  $now = Get-Date
  $matches = @($data.Items | Where-Object { $_.Score -gt 0 -and -not $_.Excluded -and (-not $_.Closing -or $_.Closing -ge $now) })
  $sent = @{}
  if (Test-Path $script:AdonaiSentPath -PathType Leaf) {
    try { foreach ($id in @(Get-Content -LiteralPath $script:AdonaiSentPath -Raw -Encoding UTF8 | ConvertFrom-Json)) { $sent[[string]$id] = $true } } catch { }
  }
  $newItems = @($matches | Where-Object { -not $sent.ContainsKey([string]$_.Id) } | Select-Object -First 50)
  if ($newItems.Count -or [bool]$config.Email.SendWhenEmpty) {
    Send-AdonaiMail $config $newItems $false
    foreach ($item in $newItems) { $sent[[string]$item.Id] = $true }
    New-Item -ItemType Directory -Path $script:AdonaiAppDir -Force | Out-Null
    @($sent.Keys | Select-Object -Last 3000) | ConvertTo-Json | Set-Content -LiteralPath $script:AdonaiSentPath -Encoding UTF8
    Write-ReportLog "Informe enviado a $(@($config.Email.Recipients).Count) destinatarios. Novedades: $($newItems.Count)."
  } else {
    Write-ReportLog 'Sin oportunidades nuevas; no se envió correo.'
  }
  if ($newItems.Count) { Show-AdonaiNotification 'ADONAI Oportunidades' "$($newItems.Count) oportunidades nuevas. El informe diario fue enviado." }
} catch {
  Write-ReportLog "ERROR: $($_.Exception.Message)"
  Show-AdonaiNotification 'ADONAI Oportunidades' "No se pudo enviar el informe diario: $($_.Exception.Message)"
  exit 1
}
