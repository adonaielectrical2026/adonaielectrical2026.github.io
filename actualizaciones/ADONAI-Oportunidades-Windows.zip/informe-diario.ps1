﻿$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'motor.ps1')

function Write-ReportLog([string]$message) {
  New-Item -ItemType Directory -Path $global:AdonaiAppDir -Force | Out-Null
  $line = "$(Get-Date -Format 'dd/MM/yyyy HH:mm:ss') · $message"
  Add-Content -LiteralPath (Join-Path $global:AdonaiAppDir 'informe-diario.log') -Value $line -Encoding UTF8
}

function Show-AdonaiNotification([string]$title, [string]$message) {
  try {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $notification = New-Object System.Windows.Forms.NotifyIcon
    $notification.Icon = [System.Drawing.SystemIcons]::Information
    $notification.BalloonTipTitle = $title
    $notification.BalloonTipText = $message
    $notification.Visible = $true
    $notification.ShowBalloonTip(7000)
    Start-Sleep -Seconds 8
    $notification.Dispose()
  } catch { }
}

try {
  $config = Get-AdonaiConfig
  if (-not [bool]$config.Email.Enabled) { Write-ReportLog 'Envío desactivado.'; exit 0 }
  $data = Get-AdonaiData $config $null $true
  $now = Get-Date
  $matches = @($data.Items | Where-Object { $_.Score -gt 0 -and -not $_.Excluded -and (-not $_.Closing -or $_.Closing -ge $now) })
  $sent = @{}
  if (Test-Path $global:AdonaiSentPath -PathType Leaf) {
    try { foreach ($id in @(Get-Content -LiteralPath $global:AdonaiSentPath -Raw -Encoding UTF8 | ConvertFrom-Json)) { $sent[[string]$id] = $true } } catch { }
  }
  $newItems = @($matches | Where-Object { -not $sent.ContainsKey([string]$_.Id) } | Select-Object -First 50)
  $followed = @{}
  $savedPath = Join-Path $global:AdonaiAppDir 'guardados.json'
  if (Test-Path $savedPath -PathType Leaf) {
    try { foreach ($id in @(Get-Content -LiteralPath $savedPath -Raw -Encoding UTF8 | ConvertFrom-Json)) { $followed[[string]$id] = $true } } catch { }
  }
  $trackingPath = Join-Path $global:AdonaiAppDir 'seguimiento.json'
  if (Test-Path $trackingPath -PathType Leaf) {
    try {
      foreach ($entry in @(Get-Content -LiteralPath $trackingPath -Raw -Encoding UTF8 | ConvertFrom-Json)) {
        if ($entry.Id -and @('Descartada','Perdida','Ganada') -notcontains [string]$entry.Status) { $followed[[string]$entry.Id] = $true }
      }
    } catch { }
  }
  $dueItems = @($matches | Where-Object {
    $_.Closing -and $followed.ContainsKey([string]$_.Id) -and ([datetime]$_.Closing - $now).TotalDays -ge 0 -and ([datetime]$_.Closing - $now).TotalDays -le 7
  } | Select-Object -First 30)
  $reportItems = @(@($newItems) + @($dueItems) | Group-Object Id | ForEach-Object { $_.Group[0] } | Select-Object -First 50)
  if ($reportItems.Count -or [bool]$config.Email.SendWhenEmpty) {
    Send-AdonaiMail $config $reportItems $false
    foreach ($item in $newItems) { $sent[[string]$item.Id] = $true }
    New-Item -ItemType Directory -Path $global:AdonaiAppDir -Force | Out-Null
    @($sent.Keys | Select-Object -Last 3000) | ConvertTo-Json | Set-Content -LiteralPath $global:AdonaiSentPath -Encoding UTF8
    Write-ReportLog "Informe enviado a $(@($config.Email.Recipients).Count) destinatarios. Novedades: $($newItems.Count). Vencimientos: $($dueItems.Count)."
  } else {
    Write-ReportLog 'Sin oportunidades nuevas; no se envió correo.'
  }
  if ($newItems.Count) { Show-AdonaiNotification 'ADONAI Oportunidades' "$($newItems.Count) oportunidades nuevas. El informe diario fue enviado." }
} catch {
  Write-ReportLog "ERROR: $($_.Exception.Message)"
  Show-AdonaiNotification 'ADONAI Oportunidades' "No se pudo enviar el informe diario: $($_.Exception.Message)"
  exit 1
}
