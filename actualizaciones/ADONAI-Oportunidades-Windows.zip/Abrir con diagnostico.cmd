@echo off
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" (
  echo ERROR: No se encontro Windows PowerShell.
  pause
  exit /b 1
)
echo Iniciando ADONAI Oportunidades con diagnostico...
echo Carpeta: %~dp0
echo.
"%PS%" -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0inicio.ps1"
echo.
echo La aplicacion se cerro. Si aparecio un error, tome una captura antes de cerrar esta ventana.
pause
