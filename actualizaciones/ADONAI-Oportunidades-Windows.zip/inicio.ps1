﻿param([switch]$InformeDiario)
$ErrorActionPreference = 'Stop'

try {
  if ($InformeDiario) {
    $reportScript = Join-Path $PSScriptRoot 'informe-diario.ps1'
    if (-not (Test-Path $reportScript -PathType Leaf)) { throw 'No se encontró el módulo de informes diarios.' }
    & $reportScript
    return
  }

  $createdNew = $false
  $mutex = New-Object System.Threading.Mutex($true, 'Local\ADONAI-Oportunidades-UI', [ref]$createdNew)
  if (-not $createdNew) { return }
  try {
    $uiScript = Join-Path $PSScriptRoot 'ui.ps1'
    if (-not (Test-Path $uiScript -PathType Leaf)) { throw 'No se encontró la interfaz de ADONAI Oportunidades.' }
    . $uiScript
  } finally {
    $mutex.ReleaseMutex()
    $mutex.Dispose()
  }
} catch {
  $appDataDir = Join-Path $env:LOCALAPPDATA 'AdonaiOportunidades'
  New-Item -ItemType Directory -Path $appDataDir -Force | Out-Null
  $logPath = Join-Path $appDataDir 'error.log'
  ($_ | Format-List * -Force | Out-String) | Set-Content -Path $logPath -Encoding UTF8
  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.MessageBox]::Show(
    "No se pudo abrir ADONAI Oportunidades.`n`n$($_.Exception.Message)`n`nSe guardaron detalles en:`n$logPath",
    'ADONAI Oportunidades', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error
  ) | Out-Null
}
