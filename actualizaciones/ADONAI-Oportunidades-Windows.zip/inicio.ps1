﻿$ErrorActionPreference = 'Stop'
try {
  & (Join-Path $PSScriptRoot 'ui.ps1')
} catch {
  $appDataDir = Join-Path $env:LOCALAPPDATA 'AdonaiOportunidades'
  New-Item -ItemType Directory -Path $appDataDir -Force | Out-Null
  $logPath = Join-Path $appDataDir 'error.log'
  ($_ | Format-List * -Force | Out-String) | Set-Content -Path $logPath -Encoding UTF8
  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.MessageBox]::Show(
    "No se pudo abrir ADONAI Oportunidades.`n`n$($_.Exception.Message)`n`nSe guardaron detalles en:`n$logPath",
    'ADONAI Oportunidades',
    [System.Windows.Forms.MessageBoxButtons]::OK,
    [System.Windows.Forms.MessageBoxIcon]::Error
  ) | Out-Null
}
