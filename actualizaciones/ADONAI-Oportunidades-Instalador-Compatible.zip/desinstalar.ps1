﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
$answer = [System.Windows.Forms.MessageBox]::Show(
  "¿Querés eliminar ADONAI Oportunidades de esta computadora?`n`nTus datos y configuraciones se conservarán.",
  'Desinstalar ADONAI Oportunidades', 'YesNo', 'Question'
)
if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { exit 0 }
try {
  $installDir = Join-Path $env:LOCALAPPDATA 'Programs\ADONAI Oportunidades'
  $desktop = [Environment]::GetFolderPath('Desktop')
  $programs = [Environment]::GetFolderPath('Programs')
  Remove-Item -LiteralPath (Join-Path $desktop 'ADONAI Oportunidades.lnk') -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath (Join-Path $programs 'ADONAI ELECTRICAL\ADONAI Oportunidades.lnk') -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath (Join-Path $programs 'ADONAI ELECTRICAL') -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\ADONAIOportunidades' -Recurse -Force -ErrorAction SilentlyContinue
  $quotedDir = "'" + $installDir.Replace("'", "''") + "'"
  $cleanup = "Start-Sleep -Seconds 2; Remove-Item -LiteralPath $quotedDir -Recurse -Force -ErrorAction SilentlyContinue"
  $bytes = [Text.Encoding]::Unicode.GetBytes($cleanup)
  $encoded = [Convert]::ToBase64String($bytes)
  Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -ArgumentList "-NoProfile -WindowStyle Hidden -EncodedCommand $encoded" -WindowStyle Hidden
  [System.Windows.Forms.MessageBox]::Show('La aplicación fue desinstalada. Tus datos quedaron guardados.', 'ADONAI Oportunidades', 'OK', 'Information') | Out-Null
  exit 0
} catch {
  [System.Windows.Forms.MessageBox]::Show("No se pudo completar la desinstalación.`n`n$($_.Exception.Message)", 'ADONAI Oportunidades', 'OK', 'Error') | Out-Null
  exit 1
}
