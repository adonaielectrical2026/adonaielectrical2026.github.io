﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$enginePath = Join-Path $PSScriptRoot 'motor.ps1'
if (Test-Path $enginePath -PathType Leaf) {
  . $enginePath
} elseif (-not (Get-Command Get-AdonaiConfig -ErrorAction SilentlyContinue)) {
  throw 'No se encontró el motor de ADONAI Oportunidades.'
}

$script:sourceUrl = 'https://www.comprasestatales.gub.uy/consultas/rss'
$script:sourceSite = 'https://www.comprasestatales.gub.uy/consultas/'
$script:uteUrl = 'https://portal.ute.com.uy/proveedores/compras/licitaciones'
$script:oseUrl = 'https://www.ose.com.uy/compras-y-acreedores/llamados-programas-con-financiamiento-externo'
$script:antelUrl = 'https://antel.com.uy/institucional/compras-y-proveedores'
$script:appVersion = [version]'1.3.0'
$script:updateManifestUrl = 'https://adonaielectrical2026.github.io/actualizaciones/adonai-oportunidades.json'
$script:appDir = Join-Path $env:LOCALAPPDATA 'AdonaiOportunidades'
$script:savedPath = Join-Path $script:appDir 'guardados.json'
$script:trackingPath = Join-Path $script:appDir 'seguimiento.json'
$script:allItems = @()
$script:visibleItems = @()
$script:saved = @{}
$script:tracking = @{}
$script:config = Get-AdonaiConfig
$script:lastData = $null
$script:categories = @(
  @{ Name = 'Instalaciones eléctricas'; Terms = @('instalacion electrica','instalaciones electricas','obra electrica','obras electricas','electrificacion','tendido electrico','cableado electrico','tablero electrico','electricista','servicios electricos') },
  @{ Name = 'Mantenimiento y reparación'; Terms = @('mantenimiento electrico','reparacion electrica','reacondicionamiento electrico','falla electrica','sistema electrico') },
  @{ Name = 'Iluminación'; Terms = @('iluminacion de emergencia','luminaria de emergencia','alumbrado de emergencia','iluminacion','luminarias') },
  @{ Name = 'Cámaras de seguridad'; Terms = @('videovigilancia','camara de seguridad','camaras de seguridad','cctv','circuito cerrado') },
  @{ Name = 'Trámites UTE'; Terms = @('tramite ute','habilitacion electrica','suministro electrico','potencia contratada','conexion electrica') }
)

function Normalize-Text([string]$value) {
  $decomposed = $value.Normalize([System.Text.NormalizationForm]::FormD)
  return ([regex]::Replace($decomposed, '\p{Mn}', '')).ToLowerInvariant()
}

function Get-NodeText($node, [string]$name) {
  $child = $node.SelectSingleNode($name)
  if ($null -eq $child) { return '' }
  return [string]$child.InnerText
}

function Get-Utf8ResponseText($response) {
  # Windows PowerShell 5.1 puede interpretar como Latin-1 una respuesta UTF-8 sin charset.
  $stream = $response.RawContentStream
  if ($null -eq $stream) { throw 'La respuesta no contiene los bytes originales.' }
  if ($stream.CanSeek) { $stream.Position = 0 }
  $reader = [System.IO.StreamReader]::new($stream, [System.Text.Encoding]::UTF8, $true)
  try { return $reader.ReadToEnd().TrimStart([char]0xFEFF) }
  finally { $reader.Dispose() }
}

function Test-TrustedUpdateUrl([string]$value) {
  try {
    $uri = [uri]$value
    return $uri.Scheme -eq 'https' -and $uri.Host -eq 'adonaielectrical2026.github.io'
  } catch { return $false }
}

function Check-ForUpdate {
  $updateButton.Enabled = $false
  $previousText = $updateButton.Text
  $updateButton.Text = 'Buscando…'
  try {
    [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
    $response = Invoke-WebRequest -Uri $script:updateManifestUrl -UserAgent 'ADONAI Oportunidades Updater' -UseBasicParsing -TimeoutSec 20
    $manifest = (Get-Utf8ResponseText $response) | ConvertFrom-Json
    if (-not $manifest.version -or -not $manifest.url -or -not $manifest.sha256) {
      throw 'El archivo de actualización está incompleto.'
    }
    $availableVersion = [version][string]$manifest.version
    if ($availableVersion -le $script:appVersion) {
      [System.Windows.Forms.MessageBox]::Show(
        "Ya tenés la versión más reciente ($($script:appVersion.ToString())).",
        'ADONAI Oportunidades', 'OK', 'Information'
      ) | Out-Null
      return
    }
    if (-not (Test-TrustedUpdateUrl ([string]$manifest.url))) {
      throw 'La descarga no pertenece al sitio oficial de ADONAI ELECTRICAL.'
    }
    $notes = if ($manifest.notes) { "`n`n$([string]$manifest.notes)" } else { '' }
    $answer = [System.Windows.Forms.MessageBox]::Show(
      "Está disponible la versión $availableVersion.$notes`n`n¿Querés descargarla e instalarla ahora?",
      'Actualización disponible', 'YesNo', 'Question'
    )
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { return }

    $updateButton.Text = 'Descargando…'
    New-Item -ItemType Directory -Path $script:appDir -Force | Out-Null
    $updateRoot = Join-Path $script:appDir ('actualizacion-' + [guid]::NewGuid().ToString('N'))
    $packageDir = Join-Path $updateRoot 'paquete'
    $zipPath = Join-Path $updateRoot 'actualizacion.zip'
    New-Item -ItemType Directory -Path $packageDir -Force | Out-Null
    Invoke-WebRequest -Uri ([string]$manifest.url) -UserAgent 'ADONAI Oportunidades Updater' -UseBasicParsing -TimeoutSec 90 -OutFile $zipPath
    $actualHash = (Get-FileHash -Path $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
    $expectedHash = ([string]$manifest.sha256).Trim().ToLowerInvariant()
    if ($actualHash -ne $expectedHash) { throw 'La descarga no superó la verificación de seguridad.' }
    Expand-Archive -Path $zipPath -DestinationPath $packageDir -Force
    foreach ($requiredFile in @('ui.ps1','inicio.ps1','actualizador.ps1','motor.ps1','informe-diario.ps1','ADONAI Oportunidades.vbs','version.txt')) {
      if (-not (Test-Path (Join-Path $packageDir $requiredFile) -PathType Leaf)) {
        throw "Falta un archivo requerido en la actualización: $requiredFile"
      }
    }

    $updaterPath = Join-Path $PSScriptRoot 'actualizador.ps1'
    $powerShellPath = Join-Path $PSHOME 'powershell.exe'
    $arguments = "-NoProfile -ExecutionPolicy Bypass -STA -File `"$updaterPath`" -PackagePath `"$packageDir`" -InstallPath `"$PSScriptRoot`" -ParentProcessId $PID"
    Start-Process -FilePath $powerShellPath -ArgumentList $arguments
    $form.Close()
  } catch {
    $message = if ($_.Exception.Response -and $_.Exception.Response.StatusCode.value__ -eq 404) {
      'El canal de actualizaciones todavía no está publicado en el sitio de ADONAI ELECTRICAL.'
    } else { $_.Exception.Message }
    [System.Windows.Forms.MessageBox]::Show(
      "No se pudo buscar o instalar la actualización.`n`n$message",
      'ADONAI Oportunidades', 'OK', 'Warning'
    ) | Out-Null
  } finally {
    if (-not $form.IsDisposed) {
      $updateButton.Enabled = $true
      $updateButton.Text = $previousText
    }
  }
}

function Get-Department([string]$value) {
  $text = ' ' + (Normalize-Text $value) + ' '
  $places = [ordered]@{
    'Artigas' = @('artigas','bella union')
    'Canelones' = @('canelones','las piedras','ciudad de la costa','pando','atlantida','santa lucia')
    'Cerro Largo' = @('cerro largo','melo','rio branco')
    'Colonia' = @('colonia','carmelo','nueva helvecia')
    'Durazno' = @('durazno','sarandi del yi')
    'Flores' = @('flores','trinidad')
    'Florida' = @('florida','sarandi grande')
    'Lavalleja' = @('lavalleja')
    'Maldonado' = @('maldonado','punta del este','piriapolis')
    'Montevideo' = @('montevideo')
    'Paysandú' = @('paysandu')
    'Río Negro' = @('rio negro','fray bentos','young')
    'Rivera' = @('rivera','tranqueras')
    'Rocha' = @('rocha','chuy','lascano')
    'Salto' = @('salto')
    'San José' = @('san jose','ciudad del plata')
    'Soriano' = @('soriano','mercedes','dolores')
    'Tacuarembó' = @('tacuarembo','paso de los toros')
    'Treinta y Tres' = @('treinta y tres','vergara')
  }
  foreach ($department in $places.Keys) {
    foreach ($place in $places[$department]) {
      if ($text.Contains(' ' + $place + ' ')) { return $department }
    }
  }
  foreach ($marker in @('pereira rossell','planta de portland manga','18 de julio 1670','cerrito1034','cerrito 1034','paraguay 2097')) {
    if ($text.Contains($marker)) { return 'Montevideo' }
  }
  return ''
}

function Get-Categories([string]$content) {
  return @((Get-AdonaiMatchInfo $content $script:config).Categories)
}

function Parse-Feed([string]$content) {
  [xml]$xml = $content
  $records = @()
  foreach ($entry in @($xml.SelectNodes('//item'))) {
    $parts = (Get-NodeText $entry 'title') -split '\|', 2
    $title = $parts[0].Trim()
    $buyer = if ($parts.Count -gt 1) { $parts[1].Trim() } else { '' }
    $link = (Get-NodeText $entry 'link').Trim()
    if ($link -notmatch '^https?://(www\.)?comprasestatales\.gub\.uy/') { continue }
    $link = $link -replace '^http:', 'https:'
    $raw = [System.Net.WebUtility]::HtmlDecode((Get-NodeText $entry 'description'))
    $description = [regex]::Replace($raw, '<[^>]*>', ' ')
    $description = [regex]::Replace($description, '\s+', ' ').Trim()
    $closing = $null
    $deadline = [regex]::Match($description, 'Recepci[oó]n de ofertas hasta:\s*(\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2})\s*hs', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    if ($deadline.Success) {
      try { $closing = [datetime]::ParseExact($deadline.Groups[1].Value, 'dd/MM/yyyy HH:mm', [System.Globalization.CultureInfo]::InvariantCulture) } catch { }
      $description = $description.Substring(0, $deadline.Index).Trim()
    }
    $published = $null
    $pubText = (Get-NodeText $entry 'pubDate') -replace '\s+\([^)]+\)$', ''
    try { $published = [datetimeoffset]::Parse($pubText, [System.Globalization.CultureInfo]::InvariantCulture).LocalDateTime } catch { }
    $records += [pscustomobject]@{
      Id = $link; Title = $title; Buyer = $buyer; Description = $description
      Department = (Get-Department "$title $description $buyer"); Closing = $closing
      Published = $published; Link = $link; Source = 'ARCE'; Categories = @(Get-Categories "$title $description")
    }
  }
  return $records
}

function Strip-Html([string]$value) {
  $text = [regex]::Replace($value, '<[^>]*>', ' ')
  return [regex]::Replace([System.Net.WebUtility]::HtmlDecode($text), '\s+', ' ').Trim()
}

function Get-RelevantDetailText([string]$html) {
  $text = Strip-Html $html
  $start = $text.IndexOf('Consulta de Publicaciones')
  if ($start -ge 0) { $text = $text.Substring($start) }
  $end = $text.Length
  foreach ($marker in @('Información de contacto:', 'Ítems del llamado', 'Agencia Reguladora de Compras Estatales')) {
    $position = $text.IndexOf($marker)
    if ($position -gt 0 -and $position -lt $end) { $end = $position }
  }
  return $text.Substring(0, $end)
}

function Complete-MissingDepartments([object[]]$records) {
  $pending = @($records | Where-Object { $_.Source -eq 'ARCE' -and $_.Categories.Count -and -not $_.Department } | Select-Object -First 25)
  $position = 0
  foreach ($item in $pending) {
    $position++
    $script:statusLabel.Text = "Completando zonas desde ARCE ($position/$($pending.Count))…"
    [System.Windows.Forms.Application]::DoEvents()
    try {
      $response = Invoke-WebRequest -Uri $item.Link -UserAgent 'Mozilla/5.0 (ADONAI Oportunidades)' -UseBasicParsing -TimeoutSec 12
      $detailText = Get-RelevantDetailText (Get-Utf8ResponseText $response)
      $department = Get-Department "$($item.Title) $($item.Buyer) $($item.Description) $detailText"
      if ($department) { $item.Department = $department }
    } catch { }
  }
}

function Resolve-OfficialLink([string]$base, [string]$rowHtml) {
  $hrefMatches = [regex]::Matches($rowHtml, 'href\s*=\s*["'']([^"'']+)["'']', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
  foreach ($match in $hrefMatches) {
    try {
      $url = [uri]::new([uri]$base, [System.Net.WebUtility]::HtmlDecode($match.Groups[1].Value))
      if ($url.Scheme -eq 'https' -and ($url.Host -match '(^|\.)(gub\.uy|ute\.com\.uy|ose\.com\.uy)$')) { return $url.AbsoluteUri }
    } catch { }
  }
  return $base
}

function Parse-DirectTable([string]$content, [string]$base, [string]$sourceName) {
  $records = @()
  $rows = [regex]::Matches($content, '<tr\b[^>]*>(.*?)</tr>', [System.Text.RegularExpressions.RegexOptions]::Singleline -bor [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
  foreach ($row in $rows) {
    $cells = @([regex]::Matches($row.Groups[1].Value, '<t[dh]\b[^>]*>(.*?)</t[dh]>', [System.Text.RegularExpressions.RegexOptions]::Singleline -bor [System.Text.RegularExpressions.RegexOptions]::IgnoreCase) | ForEach-Object { Strip-Html $_.Groups[1].Value })
    if ($cells.Count -lt 4) { continue }
    if ($sourceName -eq 'UTE') {
      $reference = $cells[0]; $title = $cells[1]; $dateText = $cells[3]
      if ($reference -eq 'DATA ROOM' -or $reference -match '^LICITACI') { continue }
      $buyer = 'UTE'; $published = $null
    } else {
      $reference = $cells[0]; $title = $cells[1]; $dateText = $cells[3]
      $buyer = 'OSE'
      $published = $null
      try { $published = [datetime]::ParseExact($reference, 'dd/MM/yyyy', [System.Globalization.CultureInfo]::InvariantCulture) } catch { }
      if ($cells.Count -gt 4 -and $cells[4] -match 'Finalizado') { continue }
    }
    if ([string]::IsNullOrWhiteSpace($title)) { continue }
    $dateMatch = [regex]::Match($dateText, '(\d{2}/\d{2}/\d{4})(?:\s+(\d{2}:\d{2}))?')
    $closing = $null
    if ($dateMatch.Success) {
      $format = if ($dateMatch.Groups[2].Success) { 'dd/MM/yyyy HH:mm' } else { 'dd/MM/yyyy' }
      $value = if ($dateMatch.Groups[2].Success) { "$($dateMatch.Groups[1].Value) $($dateMatch.Groups[2].Value)" } else { $dateMatch.Groups[1].Value }
      try { $closing = [datetime]::ParseExact($value, $format, [System.Globalization.CultureInfo]::InvariantCulture) } catch { }
    }
    $link = Resolve-OfficialLink $base $row.Groups[1].Value
    $records += [pscustomobject]@{
      Id = "$sourceName|$reference|$title"; Title = "$reference - $title"; Buyer = $buyer
      Description = $title; Department = (Get-Department $title); Closing = $closing
      Published = $published; Link = $link; Source = $sourceName; Categories = @(Get-Categories $title)
    }
  }
  return $records
}

function Load-Saved {
  if (Test-Path $script:savedPath) {
    try {
      $values = @(Get-Content $script:savedPath -Raw | ConvertFrom-Json)
      foreach ($value in $values) { $script:saved[[string]$value] = $true }
    } catch { }
  }
}

function Save-Saved {
  New-Item -ItemType Directory -Path $script:appDir -Force | Out-Null
  @($script:saved.Keys) | ConvertTo-Json | Set-Content -Path $script:savedPath -Encoding UTF8
}

function Load-Tracking {
  if (-not (Test-Path $script:trackingPath -PathType Leaf)) { return }
  try {
    foreach ($entry in @(Get-Content -LiteralPath $script:trackingPath -Raw -Encoding UTF8 | ConvertFrom-Json)) {
      if ($entry.Id) { $script:tracking[[string]$entry.Id] = [pscustomobject]@{ Status = [string]$entry.Status; Notes = [string]$entry.Notes } }
    }
  } catch { }
}

function Save-Tracking {
  New-Item -ItemType Directory -Path $script:appDir -Force | Out-Null
  $values = @()
  foreach ($id in $script:tracking.Keys) {
    $values += [pscustomobject]@{ Id = $id; Status = $script:tracking[$id].Status; Notes = $script:tracking[$id].Notes }
  }
  $values | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $script:trackingPath -Encoding UTF8
}

function Set-AdonaiDailyTask($config) {
  $taskName = 'ADONAI Oportunidades - Informe diario'
  if ([bool]$config.Email.Enabled) {
    $powerShellPath = Join-Path $PSHOME 'powershell.exe'
    $startScript = Join-Path $PSScriptRoot 'inicio.ps1'
    $taskCommand = "`"$powerShellPath`" -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File `"$startScript`" -InformeDiario"
    $output = & schtasks.exe /Create /SC DAILY /TN $taskName /TR $taskCommand /ST ([string]$config.Email.SendTime) /F 2>&1
    if ($LASTEXITCODE -ne 0) { throw "Windows no pudo crear la tarea diaria. $output" }
  } else {
    & schtasks.exe /Delete /TN $taskName /F 2>$null | Out-Null
  }
}

function Show-TrackingDialog($item) {
  $dialog = New-Object System.Windows.Forms.Form
  $dialog.Text = 'Seguimiento del llamado'; $dialog.Size = [Drawing.Size]::new(560, 390)
  $dialog.StartPosition = 'CenterParent'; $dialog.FormBorderStyle = 'FixedDialog'; $dialog.MaximizeBox = $false; $dialog.MinimizeBox = $false
  $title = New-Label $item.Title 20 18 500 45 11 $true; $dialog.Controls.Add($title)
  $dialog.Controls.Add((New-Label 'Estado' 20 76 120 22 9 $true))
  $statusBox = New-Object System.Windows.Forms.ComboBox
  $statusBox.DropDownStyle = 'DropDownList'; $statusBox.Location = [Drawing.Point]::new(20,100); $statusBox.Size = [Drawing.Size]::new(250,28)
  @('Sin revisar','Interesada','Revisar','Preparando oferta','Presentada','Ganada','Perdida','Descartada') | ForEach-Object { [void]$statusBox.Items.Add($_) }
  $dialog.Controls.Add($statusBox)
  $dialog.Controls.Add((New-Label 'Notas' 20 145 120 22 9 $true))
  $notesBox = New-Object System.Windows.Forms.TextBox
  $notesBox.Multiline = $true; $notesBox.ScrollBars = 'Vertical'; $notesBox.Location = [Drawing.Point]::new(20,169); $notesBox.Size = [Drawing.Size]::new(500,120)
  $dialog.Controls.Add($notesBox)
  if ($script:tracking.ContainsKey([string]$item.Id)) {
    $savedTracking = $script:tracking[[string]$item.Id]
    $statusBox.SelectedItem = $savedTracking.Status; $notesBox.Text = $savedTracking.Notes
  }
  if ($statusBox.SelectedIndex -lt 0) { $statusBox.SelectedIndex = 0 }
  $ok = New-Object System.Windows.Forms.Button
  $ok.Text = 'Guardar'; $ok.Location = [Drawing.Point]::new(330,306); $ok.Size = [Drawing.Size]::new(90,32)
  $cancel = New-Object System.Windows.Forms.Button
  $cancel.Text = 'Cancelar'; $cancel.Location = [Drawing.Point]::new(430,306); $cancel.Size = [Drawing.Size]::new(90,32); $cancel.DialogResult = 'Cancel'
  $ok.Add_Click({
    $script:tracking[[string]$item.Id] = [pscustomobject]@{ Status = [string]$statusBox.SelectedItem; Notes = $notesBox.Text.Trim() }
    Save-Tracking; $dialog.DialogResult = 'OK'; $dialog.Close()
  })
  $dialog.Controls.AddRange(@($ok,$cancel)); $dialog.CancelButton = $cancel
  [void]$dialog.ShowDialog($form)
  Apply-Filters
}

function Export-AdonaiCsv {
  if (-not $script:visibleItems.Count) {
    [Windows.Forms.MessageBox]::Show('No hay resultados visibles para exportar.', 'ADONAI Oportunidades', 'OK', 'Information') | Out-Null
    return
  }
  $picker = New-Object System.Windows.Forms.SaveFileDialog
  $picker.Filter = 'Archivo CSV para Excel (*.csv)|*.csv'; $picker.FileName = "ADONAI-Oportunidades-$(Get-Date -Format 'yyyy-MM-dd').csv"
  if ($picker.ShowDialog($form) -ne [Windows.Forms.DialogResult]::OK) { return }
  $rows = foreach ($item in $script:visibleItems) {
    $tracking = if ($script:tracking.ContainsKey([string]$item.Id)) { $script:tracking[[string]$item.Id] } else { $null }
    [pscustomobject][ordered]@{
      Llamado = $item.Title; Organismo = $item.Buyer; Coincidencia = "$($item.Score)%"; Zona = $(if ($item.Department) { $item.Department } else { 'Consultar pliego' })
      Cierre = $(if ($item.Closing) { ([datetime]$item.Closing).ToString('dd/MM/yyyy HH:mm') } else { 'No informada' }); Fuente = $item.Source
      Estado = $(if ($tracking) { $tracking.Status } else { 'Sin revisar' }); Notas = $(if ($tracking) { $tracking.Notes } else { '' }); Enlace = $item.Link
    }
  }
  $rows | Export-Csv -LiteralPath $picker.FileName -NoTypeInformation -Encoding UTF8 -Delimiter ';'
  [Windows.Forms.MessageBox]::Show("Archivo guardado para abrir en Excel:`n`n$($picker.FileName)", 'Exportación terminada', 'OK', 'Information') | Out-Null
}

function Show-SourceStatus {
  if ($null -eq $script:lastData) { return }
  $lines = @(
    "ARCE: $($script:lastData.Counts.ARCE) publicaciones",
    "ANTEL en ARCE: $($script:lastData.Counts.'ANTEL/ARCE') publicaciones",
    "ANTEL directo: $($script:lastData.Counts.ANTEL) publicaciones",
    "UTE: $($script:lastData.Counts.UTE) publicaciones",
    "OSE: $($script:lastData.Counts.OSE) publicaciones"
  )
  if ($script:lastData.Failures.Count) { $lines += ''; $lines += "Fuentes con problemas: $($script:lastData.Failures -join ', ')" }
  $lines += ''; $lines += 'ARCE concentra los llamados de ministerios, intendencias y numerosos entes. ANTEL también se comprueba en su portal oficial.'
  [Windows.Forms.MessageBox]::Show(($lines -join "`n"), 'Estado de las fuentes', 'OK', 'Information') | Out-Null
}

function Export-AdonaiCalendar($item) {
  if (-not $item.Closing) {
    [Windows.Forms.MessageBox]::Show('Este llamado no informa una fecha de cierre.', 'Calendario', 'OK', 'Information') | Out-Null
    return
  }
  $picker = New-Object System.Windows.Forms.SaveFileDialog
  $picker.Filter = 'Evento de calendario (*.ics)|*.ics'; $picker.FileName = "Cierre-ADONAI-$(([datetime]$item.Closing).ToString('yyyy-MM-dd')).ics"
  if ($picker.ShowDialog($form) -ne [Windows.Forms.DialogResult]::OK) { return }
  $escapeIcs = { param([string]$value) $value.Replace('\','\\').Replace(',','\,').Replace(';','\;').Replace("`r`n",'\n').Replace("`n",'\n') }
  $start = ([datetime]$item.Closing).ToUniversalTime()
  $finish = $start.AddMinutes(30)
  $title = & $escapeIcs "Cierre: $($item.Title)"
  $description = & $escapeIcs "$($item.Buyer) · $($item.Description) · $($item.Link)"
  $calendar = @(
    'BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//ADONAI ELECTRICAL//Oportunidades//ES','CALSCALE:GREGORIAN','METHOD:PUBLISH',
    'BEGIN:VEVENT',"UID:$([guid]::NewGuid().ToString())@adonai-electrical",("DTSTAMP:" + (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ')),
    ("DTSTART:" + $start.ToString('yyyyMMddTHHmmssZ')),("DTEND:" + $finish.ToString('yyyyMMddTHHmmssZ')),"SUMMARY:$title","DESCRIPTION:$description","URL:$($item.Link)",
    'BEGIN:VALARM','TRIGGER:-P1D','ACTION:DISPLAY','DESCRIPTION:El llamado cierra mañana','END:VALARM','END:VEVENT','END:VCALENDAR'
  )
  $calendar -join "`r`n" | Set-Content -LiteralPath $picker.FileName -Encoding UTF8
  Start-Process $picker.FileName
}

function Show-AdonaiTenderAnalysisDialog($item) {
  $previousStatus = $script:statusLabel.Text
  $analysisButton.Enabled = $false; $form.UseWaitCursor = $true
  try {
    $progress = { param($message) $script:statusLabel.Text = $message; [Windows.Forms.Application]::DoEvents() }
    $result = Get-AdonaiTenderAnalysis $item $progress
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = 'Análisis del llamado y sus documentos'; $dialog.Size = [Drawing.Size]::new(820,650)
    $dialog.MinimumSize = [Drawing.Size]::new(700,540); $dialog.StartPosition = 'CenterParent'
    $dialog.Controls.Add((New-Label $item.Title 20 18 750 48 11 $true))
    $report = @($result.Explanation, '')
    if ($result.Findings.Count) {
      $report += 'REQUISITOS DETECTADOS'
      foreach ($finding in $result.Findings) {
        $report += "`r`n• $($finding.Name)"
        foreach ($example in @($finding.Examples)) { $report += "  $example" }
      }
    } else { $report += 'No se detectaron requisitos específicos en el texto accesible. Revisá igualmente todos los documentos oficiales.' }
    if ($result.Warnings.Count) { $report += ''; $report += 'AVISOS'; $report += @($result.Warnings | ForEach-Object { "• $_" }) }
    $reportBox = New-Object Windows.Forms.TextBox; $reportBox.Multiline = $true; $reportBox.ReadOnly = $true; $reportBox.ScrollBars = 'Vertical'
    $reportBox.Location = [Drawing.Point]::new(20,75); $reportBox.Size = [Drawing.Size]::new(760,350); $reportBox.Anchor = 'Top,Left,Right,Bottom'; $reportBox.Text = ($report -join "`r`n")
    $dialog.Controls.Add($reportBox)
    $documentsLabel = New-Label "Documentos encontrados: $($result.Documents.Count)" 20 438 300 22 9 $true; $documentsLabel.Anchor = 'Left,Bottom'; $dialog.Controls.Add($documentsLabel)
    $documents = New-Object Windows.Forms.ListBox; $documents.Location = [Drawing.Point]::new(20,464); $documents.Size = [Drawing.Size]::new(620,72); $documents.Anchor = 'Left,Right,Bottom'
    foreach ($url in @($result.Documents)) { [void]$documents.Items.Add([string]$url) }; $dialog.Controls.Add($documents)
    $openDocument = New-Object Windows.Forms.Button; $openDocument.Text = 'Abrir documento'; $openDocument.Location = [Drawing.Point]::new(650,464); $openDocument.Size = [Drawing.Size]::new(130,32); $openDocument.Anchor = 'Right,Bottom'
    $openDocument.Enabled = ($documents.Items.Count -gt 0); $openDocument.Add_Click({ if ($documents.SelectedIndex -ge 0) { Start-Process ([string]$documents.SelectedItem) } }); $dialog.Controls.Add($openDocument)
    $close = New-Object Windows.Forms.Button; $close.Text = 'Cerrar'; $close.Location = [Drawing.Point]::new(680,555); $close.Size = [Drawing.Size]::new(100,32); $close.Anchor = 'Right,Bottom'; $close.DialogResult = 'OK'; $dialog.Controls.Add($close); $dialog.AcceptButton = $close
    [void]$dialog.ShowDialog($form)
  } catch {
    [Windows.Forms.MessageBox]::Show("No se pudo analizar este llamado.`n`n$($_.Exception.Message)", 'Análisis de documentos', 'OK', 'Warning') | Out-Null
  } finally {
    $script:statusLabel.Text = $previousStatus; $analysisButton.Enabled = $true; $form.UseWaitCursor = $false
  }
}

function Show-AdonaiDeadlineAlerts {
  if (-not [bool]$script:config.Alerts.Enabled) { return }
  $alreadyShown = @{}
  if (Test-Path $global:AdonaiAlertPath -PathType Leaf) {
    try { foreach ($key in @(Get-Content -LiteralPath $global:AdonaiAlertPath -Raw -Encoding UTF8 | ConvertFrom-Json)) { $alreadyShown[[string]$key] = $true } } catch { }
  }
  $newAlerts = @()
  foreach ($item in $script:allItems) {
    if (-not $item.Closing) { continue }
    $tracked = $script:tracking.ContainsKey([string]$item.Id) -and @('Descartada','Perdida','Ganada') -notcontains [string]$script:tracking[[string]$item.Id].Status
    if (-not $script:saved.ContainsKey([string]$item.Id) -and -not $tracked) { continue }
    $remaining = ([datetime]$item.Closing - [datetime]::Now).TotalDays
    if ($remaining -lt 0) { continue }
    $dayNumber = [Math]::Max(0, [Math]::Ceiling($remaining))
    $threshold = @(@($script:config.Alerts.Days | ForEach-Object { [int]$_ }) | Where-Object { $_ -ge $dayNumber } | Sort-Object | Select-Object -First 1)
    if (-not $threshold.Count) { continue }
    $key = "$($item.Id)|$(([datetime]$item.Closing).ToString('yyyyMMddHHmm'))|$($threshold[0])"
    if ($alreadyShown.ContainsKey($key)) { continue }
    $alreadyShown[$key] = $true
    $when = if ($dayNumber -eq 0) { 'hoy' } elseif ($dayNumber -eq 1) { 'en 1 día' } else { "en $dayNumber días" }
    $newAlerts += "• $when · $($item.Title)"
  }
  if ($newAlerts.Count) {
    New-Item -ItemType Directory -Path $global:AdonaiAppDir -Force | Out-Null
    @($alreadyShown.Keys | Select-Object -Last 3000) | ConvertTo-Json | Set-Content -LiteralPath $global:AdonaiAlertPath -Encoding UTF8
    $visibleAlerts = @($newAlerts | Select-Object -First 10)
    if ($newAlerts.Count -gt 10) { $visibleAlerts += "…y $($newAlerts.Count - 10) más." }
    [Windows.Forms.MessageBox]::Show("Próximos vencimientos de oportunidades guardadas o en seguimiento:`n`n$($visibleAlerts -join "`n")", 'Alertas de vencimiento', 'OK', 'Warning') | Out-Null
  }
}

function Show-SettingsDialog {
  $dialog = New-Object System.Windows.Forms.Form
  $dialog.Text = 'Configuración e informes diarios'; $dialog.Size = [Drawing.Size]::new(760,720)
  $dialog.MinimumSize = [Drawing.Size]::new(760,720); $dialog.StartPosition = 'CenterParent'
  $tabs = New-Object System.Windows.Forms.TabControl; $tabs.Location = [Drawing.Point]::new(18,18); $tabs.Size = [Drawing.Size]::new(708,600)
  $termsTab = New-Object System.Windows.Forms.TabPage; $termsTab.Text = 'Palabras de búsqueda'
  $emailTab = New-Object System.Windows.Forms.TabPage; $emailTab.Text = 'Informes por correo'
  $dataTab = New-Object System.Windows.Forms.TabPage; $dataTab.Text = 'Alertas y respaldo'
  [void]$tabs.TabPages.Add($termsTab); [void]$tabs.TabPages.Add($emailTab); [void]$tabs.TabPages.Add($dataTab); $dialog.Controls.Add($tabs)

  $termsTab.Controls.Add((New-Label 'Palabras adicionales' 20 22 300 24 11 $true))
  $termsTab.Controls.Add((New-Label 'Una palabra o frase por línea. Se suman a los servicios eléctricos ya incluidos.' 20 50 640 38 9))
  $includeBox = New-Object System.Windows.Forms.TextBox; $includeBox.Multiline = $true; $includeBox.ScrollBars = 'Vertical'
  $includeBox.Location = [Drawing.Point]::new(20,91); $includeBox.Size = [Drawing.Size]::new(640,145); $includeBox.Text = (@($script:config.IncludeTerms) -join "`r`n"); $termsTab.Controls.Add($includeBox)
  $termsTab.Controls.Add((New-Label 'Excluir resultados que contengan' 20 265 350 24 11 $true))
  $termsTab.Controls.Add((New-Label 'Sirve para eliminar compras que usan una palabra coincidente pero no requieren sus servicios.' 20 293 640 38 9))
  $excludeBox = New-Object System.Windows.Forms.TextBox; $excludeBox.Multiline = $true; $excludeBox.ScrollBars = 'Vertical'
  $excludeBox.Location = [Drawing.Point]::new(20,334); $excludeBox.Size = [Drawing.Size]::new(640,145); $excludeBox.Text = (@($script:config.ExcludeTerms) -join "`r`n"); $termsTab.Controls.Add($excludeBox)

  $enabledBox = New-Object System.Windows.Forms.CheckBox; $enabledBox.Text = 'Enviar automáticamente un informe cada día'; $enabledBox.AutoSize = $true
  $enabledBox.Location = [Drawing.Point]::new(20,20); $enabledBox.Checked = [bool]$script:config.Email.Enabled; $emailTab.Controls.Add($enabledBox)
  $emailTab.Controls.Add((New-Label 'Destinatarios' 20 58 180 22 9 $true))
  $recipientInput = New-Object System.Windows.Forms.TextBox; $recipientInput.Location = [Drawing.Point]::new(20,82); $recipientInput.Size = [Drawing.Size]::new(350,27); $emailTab.Controls.Add($recipientInput)
  $addRecipient = New-Object System.Windows.Forms.Button; $addRecipient.Text = 'Agregar'; $addRecipient.Location = [Drawing.Point]::new(380,80); $addRecipient.Size = [Drawing.Size]::new(90,30); $emailTab.Controls.Add($addRecipient)
  $removeRecipient = New-Object System.Windows.Forms.Button; $removeRecipient.Text = 'Quitar'; $removeRecipient.Location = [Drawing.Point]::new(480,80); $removeRecipient.Size = [Drawing.Size]::new(90,30); $emailTab.Controls.Add($removeRecipient)
  $recipientList = New-Object System.Windows.Forms.ListBox; $recipientList.Location = [Drawing.Point]::new(20,118); $recipientList.Size = [Drawing.Size]::new(640,82)
  foreach ($recipient in @($script:config.Email.Recipients)) { [void]$recipientList.Items.Add([string]$recipient) }; $emailTab.Controls.Add($recipientList)
  $addRecipient.Add_Click({
    $value = $recipientInput.Text.Trim()
    if (-not (Test-AdonaiEmail $value)) { [Windows.Forms.MessageBox]::Show('Escribí un correo válido.', 'Destinatarios', 'OK', 'Warning') | Out-Null; return }
    if ($recipientList.Items -notcontains $value) { [void]$recipientList.Items.Add($value) }
    $recipientInput.Clear(); $recipientInput.Focus()
  })
  $removeRecipient.Add_Click({ if ($recipientList.SelectedIndex -ge 0) { $recipientList.Items.RemoveAt($recipientList.SelectedIndex) } })

  $emailTab.Controls.Add((New-Label 'Correo remitente' 20 218 180 22 9 $true))
  $senderBox = New-Object Windows.Forms.TextBox; $senderBox.Location = [Drawing.Point]::new(20,242); $senderBox.Size = [Drawing.Size]::new(300,27); $senderBox.Text = [string]$script:config.Email.Sender; $emailTab.Controls.Add($senderBox)
  $emailTab.Controls.Add((New-Label 'Usuario SMTP' 340 218 180 22 9 $true))
  $userBox = New-Object Windows.Forms.TextBox; $userBox.Location = [Drawing.Point]::new(340,242); $userBox.Size = [Drawing.Size]::new(320,27); $userBox.Text = [string]$script:config.Email.AuthUser; $emailTab.Controls.Add($userBox)
  $emailTab.Controls.Add((New-Label 'Servidor SMTP' 20 285 180 22 9 $true))
  $serverBox = New-Object Windows.Forms.TextBox; $serverBox.Location = [Drawing.Point]::new(20,309); $serverBox.Size = [Drawing.Size]::new(250,27); $serverBox.Text = [string]$script:config.Email.SmtpServer; $emailTab.Controls.Add($serverBox)
  $emailTab.Controls.Add((New-Label 'Puerto' 290 285 80 22 9 $true))
  $portBox = New-Object Windows.Forms.NumericUpDown; $portBox.Location = [Drawing.Point]::new(290,309); $portBox.Size = [Drawing.Size]::new(90,27); $portBox.Minimum = 1; $portBox.Maximum = 65535; $portBox.Value = [decimal][int]$script:config.Email.Port; $emailTab.Controls.Add($portBox)
  $sslBox = New-Object Windows.Forms.CheckBox; $sslBox.Text = 'Usar conexión segura (SSL/TLS)'; $sslBox.AutoSize = $true; $sslBox.Location = [Drawing.Point]::new(405,311); $sslBox.Checked = [bool]$script:config.Email.UseSsl; $emailTab.Controls.Add($sslBox)
  $emailTab.Controls.Add((New-Label 'Contraseña de aplicación' 20 354 250 22 9 $true))
  $passwordBox = New-Object Windows.Forms.TextBox; $passwordBox.Location = [Drawing.Point]::new(20,378); $passwordBox.Size = [Drawing.Size]::new(360,27); $passwordBox.UseSystemPasswordChar = $true; $emailTab.Controls.Add($passwordBox)
  $passwordHint = New-Label 'Dejala vacía para conservar la ya guardada. En Gmail debe ser una contraseña de aplicación.' 20 410 640 38 8
  $passwordHint.ForeColor = [Drawing.Color]::FromArgb(95,110,130); $emailTab.Controls.Add($passwordHint)
  $emailTab.Controls.Add((New-Label 'Hora diaria' 20 458 120 22 9 $true))
  $timeBox = New-Object Windows.Forms.DateTimePicker; $timeBox.Format = 'Custom'; $timeBox.CustomFormat = 'HH:mm'; $timeBox.ShowUpDown = $true; $timeBox.Location = [Drawing.Point]::new(20,482); $timeBox.Size = [Drawing.Size]::new(110,27)
  try { $timeBox.Value = [datetime]::ParseExact([string]$script:config.Email.SendTime, 'HH:mm', [Globalization.CultureInfo]::InvariantCulture) } catch { }
  $emailTab.Controls.Add($timeBox)
  $emptyBox = New-Object Windows.Forms.CheckBox; $emptyBox.Text = 'Enviar también cuando no haya novedades'; $emptyBox.AutoSize = $true; $emptyBox.Location = [Drawing.Point]::new(160,485); $emptyBox.Checked = [bool]$script:config.Email.SendWhenEmpty; $emailTab.Controls.Add($emptyBox)
  $testButton = New-Object Windows.Forms.Button; $testButton.Text = 'Enviar correo de prueba'; $testButton.Location = [Drawing.Point]::new(460,472); $testButton.Size = [Drawing.Size]::new(200,38); $emailTab.Controls.Add($testButton)

  $dataTab.Controls.Add((New-Label 'Alertas de vencimiento' 20 24 350 28 12 $true))
  $alertsBox = New-Object Windows.Forms.CheckBox; $alertsBox.Text = 'Avisarme cuando una oportunidad guardada o en seguimiento esté por cerrar'; $alertsBox.AutoSize = $true
  $alertsBox.Location = [Drawing.Point]::new(20,62); $alertsBox.Checked = [bool]$script:config.Alerts.Enabled; $dataTab.Controls.Add($alertsBox)
  $alertHint = New-Label 'El programa avisa al faltar 7, 3 y 1 día, y el día del cierre.' 40 92 600 35 9
  $alertHint.ForeColor = [Drawing.Color]::FromArgb(95,110,130); $dataTab.Controls.Add($alertHint)
  $dataTab.Controls.Add((New-Label 'Copias de seguridad' 20 155 350 28 12 $true))
  $dataTab.Controls.Add((New-Label 'Guarda destinatarios, configuración, oportunidades, estados y notas en un solo archivo.' 20 190 630 42 9))
  $backupButton = New-Object Windows.Forms.Button; $backupButton.Text = 'Crear copia de seguridad'; $backupButton.Location = [Drawing.Point]::new(20,242); $backupButton.Size = [Drawing.Size]::new(205,38); $dataTab.Controls.Add($backupButton)
  $restoreButton = New-Object Windows.Forms.Button; $restoreButton.Text = 'Restaurar una copia'; $restoreButton.Location = [Drawing.Point]::new(240,242); $restoreButton.Size = [Drawing.Size]::new(180,38); $dataTab.Controls.Add($restoreButton)
  $backupButton.Add_Click({
    $picker = New-Object Windows.Forms.SaveFileDialog; $picker.Filter = 'Copia de ADONAI (*.zip)|*.zip'; $picker.FileName = "ADONAI-Respaldo-$(Get-Date -Format 'yyyy-MM-dd').zip"
    if ($picker.ShowDialog($dialog) -ne [Windows.Forms.DialogResult]::OK) { return }
    try { New-AdonaiBackup $picker.FileName; [Windows.Forms.MessageBox]::Show("Copia guardada en:`n$($picker.FileName)", 'Respaldo terminado', 'OK', 'Information') | Out-Null }
    catch { [Windows.Forms.MessageBox]::Show($_.Exception.Message, 'No se pudo crear la copia', 'OK', 'Warning') | Out-Null }
  })
  $restoreButton.Add_Click({
    $picker = New-Object Windows.Forms.OpenFileDialog; $picker.Filter = 'Copia de ADONAI (*.zip)|*.zip'
    if ($picker.ShowDialog($dialog) -ne [Windows.Forms.DialogResult]::OK) { return }
    $answer = [Windows.Forms.MessageBox]::Show('Se reemplazarán los datos actuales por los de la copia seleccionada. ¿Continuar?', 'Restaurar copia', 'YesNo', 'Question')
    if ($answer -ne [Windows.Forms.DialogResult]::Yes) { return }
    try {
      Restore-AdonaiBackup $picker.FileName
      [Windows.Forms.MessageBox]::Show('La copia fue restaurada. Cerrá y volvé a abrir la aplicación para cargar todos los datos.', 'Restauración terminada', 'OK', 'Information') | Out-Null
    } catch { [Windows.Forms.MessageBox]::Show($_.Exception.Message, 'No se pudo restaurar', 'OK', 'Warning') | Out-Null }
  })

  $collectConfig = {
    $newConfig = New-AdonaiDefaultConfig
    $newConfig.IncludeTerms = @($includeBox.Lines | ForEach-Object { $_.Trim() } | Where-Object { $_ } | Select-Object -Unique)
    $newConfig.ExcludeTerms = @($excludeBox.Lines | ForEach-Object { $_.Trim() } | Where-Object { $_ } | Select-Object -Unique)
    $newConfig.Email.Enabled = $enabledBox.Checked; $newConfig.Email.Recipients = @($recipientList.Items | ForEach-Object { [string]$_ })
    $newConfig.Email.Sender = $senderBox.Text.Trim(); $newConfig.Email.AuthUser = $userBox.Text.Trim(); $newConfig.Email.SmtpServer = $serverBox.Text.Trim()
    $newConfig.Email.Port = [int]$portBox.Value; $newConfig.Email.UseSsl = $sslBox.Checked; $newConfig.Email.SendTime = $timeBox.Value.ToString('HH:mm'); $newConfig.Email.SendWhenEmpty = $emptyBox.Checked
    $newConfig.Email.PasswordEncrypted = if ($passwordBox.Text) { Protect-AdonaiPassword $passwordBox.Text } else { [string]$script:config.Email.PasswordEncrypted }
    $newConfig.Alerts.Enabled = $alertsBox.Checked; $newConfig.Alerts.Days = @(7,3,1,0)
    return $newConfig
  }
  $testButton.Add_Click({
    try {
      $candidate = & $collectConfig
      $sample = [pscustomobject]@{ Title = 'Correo de prueba de ADONAI Oportunidades'; Buyer = 'ADONAI ELECTRICAL'; Department = 'Uruguay'; Closing = (Get-Date).AddDays(7); Link = 'https://adonaielectrical2026.github.io/'; Score = 99 }
      $dialog.UseWaitCursor = $true; Send-AdonaiMail $candidate @($sample) $true
      [Windows.Forms.MessageBox]::Show('El correo de prueba fue enviado.', 'Informes diarios', 'OK', 'Information') | Out-Null
    } catch { [Windows.Forms.MessageBox]::Show("No se pudo enviar el correo de prueba.`n`n$($_.Exception.Message)", 'Informes diarios', 'OK', 'Warning') | Out-Null }
    finally { $dialog.UseWaitCursor = $false }
  })
  $saveButton = New-Object Windows.Forms.Button; $saveButton.Text = 'Guardar configuración'; $saveButton.Location = [Drawing.Point]::new(488,632); $saveButton.Size = [Drawing.Size]::new(145,34)
  $cancelButton = New-Object Windows.Forms.Button; $cancelButton.Text = 'Cancelar'; $cancelButton.Location = [Drawing.Point]::new(641,632); $cancelButton.Size = [Drawing.Size]::new(85,34); $cancelButton.DialogResult = 'Cancel'
  $saveButton.Add_Click({
    try {
      $candidate = & $collectConfig
      if ($candidate.Email.Enabled) {
        if (-not $candidate.Email.Recipients.Count) { throw 'Agregá al menos un destinatario.' }
        if (-not (Test-AdonaiEmail $candidate.Email.Sender)) { throw 'Indicá un correo remitente válido.' }
        if (-not $candidate.Email.SmtpServer) { throw 'Indicá el servidor SMTP.' }
        if (-not $candidate.Email.PasswordEncrypted) { throw 'Indicá la contraseña de aplicación del correo.' }
      }
      Save-AdonaiConfig $candidate; Set-AdonaiDailyTask $candidate; $script:config = $candidate
      $dialog.DialogResult = 'OK'; $dialog.Close()
    } catch { [Windows.Forms.MessageBox]::Show($_.Exception.Message, 'No se pudo guardar', 'OK', 'Warning') | Out-Null }
  })
  $dialog.Controls.AddRange(@($saveButton,$cancelButton)); $dialog.CancelButton = $cancelButton
  if ($dialog.ShowDialog($form) -eq [Windows.Forms.DialogResult]::OK) { Refresh-Data }
}

function New-Label([string]$text, [int]$x, [int]$y, [int]$width, [int]$height, [int]$size = 9, [bool]$bold = $false) {
  $label = New-Object System.Windows.Forms.Label
  $label.Text = $text; $label.Location = [System.Drawing.Point]::new($x, $y)
  $label.Size = [System.Drawing.Size]::new($width, $height)
  $style = if ($bold) { [System.Drawing.FontStyle]::Bold } else { [System.Drawing.FontStyle]::Regular }
  $label.Font = [System.Drawing.Font]::new('Segoe UI', $size, $style)
  return $label
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'ADONAI ELECTRICAL · Oportunidades'
$appIconPath = Join-Path $PSScriptRoot 'ADONAI Oportunidades.ico'
if (Test-Path $appIconPath -PathType Leaf) {
  try { $form.Icon = New-Object System.Drawing.Icon($appIconPath) } catch { }
}
$form.Size = [System.Drawing.Size]::new(1220, 790)
$form.MinimumSize = [System.Drawing.Size]::new(970, 640)
$form.StartPosition = 'CenterScreen'
$form.BackColor = [System.Drawing.Color]::FromArgb(245, 247, 250)
$form.Font = [System.Drawing.Font]::new('Segoe UI', 9)

$root = New-Object System.Windows.Forms.TableLayoutPanel
$root.Dock = 'Fill'; $root.Margin = [System.Windows.Forms.Padding]::Empty
$root.Padding = [System.Windows.Forms.Padding]::Empty
$root.ColumnCount = 1; $root.RowCount = 3
[void]$root.ColumnStyles.Add([System.Windows.Forms.ColumnStyle]::new([System.Windows.Forms.SizeType]::Percent, 100))
[void]$root.RowStyles.Add([System.Windows.Forms.RowStyle]::new([System.Windows.Forms.SizeType]::Absolute, 94))
[void]$root.RowStyles.Add([System.Windows.Forms.RowStyle]::new([System.Windows.Forms.SizeType]::Percent, 100))
[void]$root.RowStyles.Add([System.Windows.Forms.RowStyle]::new([System.Windows.Forms.SizeType]::Absolute, 24))
$form.Controls.Add($root)

$body = New-Object System.Windows.Forms.TableLayoutPanel
$body.Dock = 'Fill'; $body.Margin = [System.Windows.Forms.Padding]::Empty
$body.Padding = [System.Windows.Forms.Padding]::Empty
$body.ColumnCount = 2; $body.RowCount = 1
[void]$body.ColumnStyles.Add([System.Windows.Forms.ColumnStyle]::new([System.Windows.Forms.SizeType]::Absolute, 250))
[void]$body.ColumnStyles.Add([System.Windows.Forms.ColumnStyle]::new([System.Windows.Forms.SizeType]::Percent, 100))
[void]$body.RowStyles.Add([System.Windows.Forms.RowStyle]::new([System.Windows.Forms.SizeType]::Percent, 100))
$root.Controls.Add($body, 0, 1)

$header = New-Object System.Windows.Forms.Panel
$header.Dock = 'Fill'; $header.Margin = [System.Windows.Forms.Padding]::Empty
$header.BackColor = [System.Drawing.Color]::FromArgb(16, 26, 43)
$headerTitle = New-Label 'ADONAI ELECTRICAL' 24 15 500 27 15 $true
$headerTitle.ForeColor = [System.Drawing.Color]::White
$headerSubtitle = New-Label 'Oportunidades de compras públicas · Uruguay' 25 49 600 22 9
$headerSubtitle.ForeColor = [System.Drawing.Color]::FromArgb(187, 198, 214)
$header.Controls.AddRange(@($headerTitle,$headerSubtitle))
$updatePanel = New-Object System.Windows.Forms.Panel
$updatePanel.Dock = 'Right'; $updatePanel.Width = 455
$versionLabel = New-Label "Versión $($script:appVersion.ToString())" 14 10 205 21 8
$versionLabel.ForeColor = [System.Drawing.Color]::FromArgb(187, 198, 214)
$updateButton = New-Object System.Windows.Forms.Button
$updateButton.Text = 'Buscar actualizaciones'
$updateButton.Location = [System.Drawing.Point]::new(234, 37)
$updateButton.Size = [System.Drawing.Size]::new(200, 34)
$updateButton.FlatStyle = 'Flat'
$updateButton.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(95, 116, 145)
$updateButton.BackColor = [System.Drawing.Color]::FromArgb(28, 45, 70)
$updateButton.UseVisualStyleBackColor = $false
$updateButton.ForeColor = [System.Drawing.Color]::White
$settingsButton = New-Object System.Windows.Forms.Button
$settingsButton.Text = 'Configuración e informes'
$settingsButton.Location = [System.Drawing.Point]::new(14, 37); $settingsButton.Size = [System.Drawing.Size]::new(205,34)
$settingsButton.FlatStyle = 'Flat'; $settingsButton.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(95,116,145)
$settingsButton.BackColor = [System.Drawing.Color]::FromArgb(28,45,70); $settingsButton.UseVisualStyleBackColor = $false; $settingsButton.ForeColor = [System.Drawing.Color]::White
$updatePanel.Controls.AddRange(@($versionLabel,$settingsButton,$updateButton))
$header.Controls.Add($updatePanel)
$root.Controls.Add($header, 0, 0)

$footer = New-Object System.Windows.Forms.StatusStrip
$footer.Dock = 'Fill'; $footer.Margin = [System.Windows.Forms.Padding]::Empty
$footer.BackColor = [System.Drawing.Color]::FromArgb(232, 236, 242)
$script:statusLabel = New-Object System.Windows.Forms.ToolStripStatusLabel
$script:statusLabel.Text = 'Preparando consulta de ARCE…'
$footer.Items.Add($script:statusLabel) | Out-Null
$root.Controls.Add($footer, 0, 2)

$sidebar = New-Object System.Windows.Forms.Panel
$sidebar.Dock = 'Fill'; $sidebar.Margin = [System.Windows.Forms.Padding]::Empty
$sidebar.Padding = [System.Windows.Forms.Padding]::new(14)
$sidebar.BackColor = [System.Drawing.Color]::White
$body.Controls.Add($sidebar, 0, 0)
$sidebarTitle = New-Label 'FILTROS' 18 22 200 25 10 $true
$sidebar.Controls.Add($sidebarTitle)
$sidebar.Controls.Add((New-Label 'Buscar' 18 66 210 20 9 $true))
$search = New-Object System.Windows.Forms.TextBox
$search.Location = [System.Drawing.Point]::new(18, 90); $search.Size = [System.Drawing.Size]::new(212, 28)
$sidebar.Controls.Add($search)
$sidebar.Controls.Add((New-Label 'Zona' 18 141 210 20 9 $true))
$zone = New-Object System.Windows.Forms.ComboBox
$zone.DropDownStyle = 'DropDownList'; $zone.Location = [System.Drawing.Point]::new(18, 165)
$zone.Size = [System.Drawing.Size]::new(212, 28)
@('Todo Uruguay','Salto','Litoral norte') | ForEach-Object { [void]$zone.Items.Add($_) }
$zone.SelectedIndex = 0; $sidebar.Controls.Add($zone)
$sidebar.Controls.Add((New-Label 'Estado' 18 216 210 20 9 $true))
$state = New-Object System.Windows.Forms.ComboBox
$state.DropDownStyle = 'DropDownList'; $state.Location = [System.Drawing.Point]::new(18, 240)
$state.Size = [System.Drawing.Size]::new(212, 28)
@('Abiertos para ofertar','Todos los publicados','Sin fecha de cierre') | ForEach-Object { [void]$state.Items.Add($_) }
$state.SelectedIndex = 1; $sidebar.Controls.Add($state)
$sidebar.Controls.Add((New-Label 'Fuente' 18 294 210 20 9 $true))
$sourceFilter = New-Object System.Windows.Forms.ComboBox
$sourceFilter.DropDownStyle = 'DropDownList'; $sourceFilter.Location = [System.Drawing.Point]::new(18, 318)
$sourceFilter.Size = [System.Drawing.Size]::new(212, 28)
@('Todas las fuentes','ARCE','ANTEL/ARCE','ANTEL','UTE','OSE') | ForEach-Object { [void]$sourceFilter.Items.Add($_) }
$sourceFilter.SelectedIndex = 0; $sidebar.Controls.Add($sourceFilter)
$sidebar.Controls.Add((New-Label 'Servicios' 18 365 210 20 9 $true))
$services = New-Object System.Windows.Forms.CheckedListBox
$services.Location = [System.Drawing.Point]::new(18, 389); $services.Size = [System.Drawing.Size]::new(212, 154)
$services.BorderStyle = 'None'; $services.CheckOnClick = $true
foreach ($category in $script:categories) { [void]$services.Items.Add($category.Name, $true) }
[void]$services.Items.Add('Palabras personalizadas', $true)
$sidebar.Controls.Add($services)
$main = New-Object System.Windows.Forms.Panel
$main.Dock = 'Fill'; $main.Margin = [System.Windows.Forms.Padding]::Empty
$main.Padding = [System.Windows.Forms.Padding]::new(20)
$body.Controls.Add($main, 1, 0)
$pageTitle = New-Label 'Llamados relevantes' 22 17 600 38 16 $true
$main.Controls.Add($pageTitle)
$script:summary = New-Label 'Consultando ARCE…' 24 56 650 23 9
$script:summary.ForeColor = [System.Drawing.Color]::FromArgb(105, 119, 138)
$main.Controls.Add($script:summary)
$refresh = New-Object System.Windows.Forms.Button
$refresh.Text = 'Actualizar'; $refresh.Size = New-Object System.Drawing.Size(110, 32)
$refresh.Anchor = 'Top,Right'; $refresh.Location = [System.Drawing.Point]::new(790, 26)
$main.Controls.Add($refresh)
$export = New-Object System.Windows.Forms.Button
$export.Text = 'Exportar a Excel'; $export.Size = [Drawing.Size]::new(130,32); $export.Anchor = 'Top,Right'; $main.Controls.Add($export)
$sourcesButton = New-Object System.Windows.Forms.Button
$sourcesButton.Text = 'Estado de fuentes'; $sourcesButton.Size = [Drawing.Size]::new(130,32); $sourcesButton.Anchor = 'Top,Right'; $main.Controls.Add($sourcesButton)
$onlySaved = New-Object System.Windows.Forms.CheckBox
$onlySaved.Text = 'Solo guardados'; $onlySaved.AutoSize = $true
$onlySaved.Location = [System.Drawing.Point]::new(24, 88)
$main.Controls.Add($onlySaved)
$list = New-Object System.Windows.Forms.ListView
$list.View = 'Details'; $list.FullRowSelect = $true; $list.MultiSelect = $false
$list.HideSelection = $false; $list.Location = [System.Drawing.Point]::new(22, 122)
$list.Size = [System.Drawing.Size]::new(880, 330)
$list.Anchor = 'Top,Left,Right,Bottom'
[void]$list.Columns.Add('Llamado', 290)
[void]$list.Columns.Add('Organismo', 150)
[void]$list.Columns.Add('Coincidencia', 82)
[void]$list.Columns.Add('Vence en', 75)
[void]$list.Columns.Add('Cierre', 115)
[void]$list.Columns.Add('Zona', 95)
[void]$list.Columns.Add('Fuente', 85)
$main.Controls.Add($list)

$detail = New-Object System.Windows.Forms.Panel
$detail.Location = [System.Drawing.Point]::new(22, 465)
$detail.Size = [System.Drawing.Size]::new(880, 260)
$detail.Anchor = 'Left,Right,Bottom'
$detail.BackColor = [System.Drawing.Color]::White
$main.Controls.Add($detail)
$script:detailTitle = New-Label 'Seleccioná un llamado para ver sus detalles' 17 12 700 31 12 $true
$script:detailTitle.Anchor = 'Top,Left,Right'; $detail.Controls.Add($script:detailTitle)
$script:detailInfo = New-Label '' 18 46 700 20 9
$script:detailInfo.ForeColor = [System.Drawing.Color]::FromArgb(85, 99, 118)
$detail.Controls.Add($script:detailInfo)
$script:detailDescription = New-Object System.Windows.Forms.TextBox
$script:detailDescription.Multiline = $true; $script:detailDescription.ReadOnly = $true
$script:detailDescription.ScrollBars = 'Vertical'; $script:detailDescription.BorderStyle = 'None'
$script:detailDescription.Location = [System.Drawing.Point]::new(18, 75)
$script:detailDescription.Size = [System.Drawing.Size]::new(830, 83)
$script:detailDescription.Anchor = 'Top,Left,Right'; $detail.Controls.Add($script:detailDescription)
$open = New-Object System.Windows.Forms.Button
$open.Text = 'Ver llamado oficial'; $open.Location = [System.Drawing.Point]::new(18, 173)
$open.Size = [System.Drawing.Size]::new(160, 31); $open.Enabled = $false
$detail.Controls.Add($open)
$save = New-Object System.Windows.Forms.Button
$save.Text = 'Guardar'; $save.Location = [System.Drawing.Point]::new(188, 173)
$save.Size = [System.Drawing.Size]::new(100, 31); $save.Enabled = $false
$detail.Controls.Add($save)
$portals = New-Object System.Windows.Forms.Button
$portals.Text = 'Portales oficiales ▾'; $portals.Location = [System.Drawing.Point]::new(305, 173)
$portals.Size = [System.Drawing.Size]::new(155, 31); $detail.Controls.Add($portals)
$trackingButton = New-Object System.Windows.Forms.Button
$trackingButton.Text = 'Seguimiento y notas'; $trackingButton.Location = [Drawing.Point]::new(470,173); $trackingButton.Size = [Drawing.Size]::new(165,31); $trackingButton.Enabled = $false
$detail.Controls.Add($trackingButton)
$analysisButton = New-Object System.Windows.Forms.Button
$analysisButton.Text = 'Analizar llamado y pliegos'; $analysisButton.Location = [Drawing.Point]::new(18,214); $analysisButton.Size = [Drawing.Size]::new(205,31); $analysisButton.Enabled = $false
$detail.Controls.Add($analysisButton)
$calendarButton = New-Object System.Windows.Forms.Button
$calendarButton.Text = 'Agregar al calendario'; $calendarButton.Location = [Drawing.Point]::new(233,214); $calendarButton.Size = [Drawing.Size]::new(175,31); $calendarButton.Enabled = $false
$detail.Controls.Add($calendarButton)
$portalMenu = New-Object System.Windows.Forms.ContextMenuStrip
foreach ($portal in @(
  @{ Name = 'ARCE · Estado y gobiernos departamentales'; Url = $script:sourceSite },
  @{ Name = 'UTE · Licitaciones'; Url = $script:uteUrl },
  @{ Name = 'ANTEL · Compras y proveedores'; Url = $script:antelUrl },
  @{ Name = 'OSE · Licitaciones'; Url = 'https://www.ose.com.uy/compras-y-acreedores/licitaciones-y-compras' },
  @{ Name = 'OSE · Programas especiales'; Url = $script:oseUrl }
)) {
  $menuItem = [System.Windows.Forms.ToolStripMenuItem]::new($portal.Name)
  $menuItem.Tag = $portal.Url
  $menuItem.Add_Click({ Start-Process $this.Tag })
  [void]$portalMenu.Items.Add($menuItem)
}

function Update-Details {
  if ($list.SelectedItems.Count -eq 0) {
    $script:detailTitle.Text = 'Seleccioná un llamado para ver sus detalles'
    $script:detailInfo.Text = ''; $script:detailDescription.Text = ''
    $open.Enabled = $false; $save.Enabled = $false; $trackingButton.Enabled = $false; $analysisButton.Enabled = $false; $calendarButton.Enabled = $false
    return
  }
  $item = $list.SelectedItems[0].Tag
  $script:detailTitle.Text = $item.Title
  $closing = if ($item.Closing) { $item.Closing.ToString('dd/MM/yyyy HH:mm') } else { 'No informada' }
  $department = if ($item.Department) { $item.Department } else { 'Consultar pliego' }
  $trackingText = if ($script:tracking.ContainsKey([string]$item.Id)) { "   ·   Estado: $($script:tracking[[string]$item.Id].Status)" } else { '' }
  $script:detailInfo.Text = "Coincidencia: $($item.Score)%   ·   Fuente: $($item.Source)   ·   Zona: $department   ·   Cierre: $closing$trackingText"
  $terms = if (@($item.MatchedTerms).Count) { "`r`n`r`nCoincidencias: $(@($item.MatchedTerms) -join ', ')" } else { '' }
  $explanation = Get-AdonaiMatchExplanation $item
  $script:detailDescription.Text = "$($item.Description)$terms`r`n`r`n$explanation"
  $save.Text = if ($script:saved.ContainsKey($item.Id)) { '★ Guardado' } else { '☆ Guardar' }
  $open.Enabled = $true; $save.Enabled = $true; $trackingButton.Enabled = $true; $analysisButton.Enabled = $true; $calendarButton.Enabled = [bool]$item.Closing
}

function Apply-Filters {
  $list.BeginUpdate(); $list.Items.Clear()
  $queryWords = @((Normalize-Text $search.Text).Split(' ', [System.StringSplitOptions]::RemoveEmptyEntries))
  $checked = @(); foreach ($category in $services.CheckedItems) { $checked += [string]$category }
  $today = [datetime]::Now
  $visible = @()
  foreach ($item in $script:allItems) {
    if ($onlySaved.Checked -and -not $script:saved.ContainsKey($item.Id)) { continue }
    if ($sourceFilter.SelectedIndex -gt 0 -and $item.Source -ne $sourceFilter.Text) { continue }
    $matchingCategory = $false
    foreach ($category in $item.Categories) {
      if ($checked -contains $category) { $matchingCategory = $true; break }
    }
    if (-not $matchingCategory) { continue }
    $searchText = Normalize-Text "$($item.Title) $($item.Description) $($item.Buyer)"
    $matchesQuery = $true
    foreach ($word in $queryWords) {
      if (-not $searchText.Contains($word)) { $matchesQuery = $false; break }
    }
    if (-not $matchesQuery) { continue }
    if ($zone.SelectedIndex -eq 1 -and $item.Department -ne 'Salto') { continue }
    if ($zone.SelectedIndex -eq 2 -and @('Salto','Artigas','Paysandú','Río Negro') -notcontains $item.Department) { continue }
    if ($state.SelectedIndex -eq 0 -and (-not $item.Closing -or $item.Closing -lt $today)) { continue }
    if ($state.SelectedIndex -eq 2 -and $item.Closing) { continue }
    $visible += $item
  }
  $visible = @($visible | Sort-Object -Property @{ Expression = 'Score'; Descending = $true }, @{ Expression = { if ($_.Closing) { $_.Closing } else { [datetime]::MaxValue } } })
  $script:visibleItems = $visible
  foreach ($item in $visible) {
    $statusPrefix = if ($script:tracking.ContainsKey([string]$item.Id) -and $script:tracking[[string]$item.Id].Status -ne 'Sin revisar') { "[$($script:tracking[[string]$item.Id].Status)] " } else { '' }
    $label = $statusPrefix + $(if ($script:saved.ContainsKey($item.Id)) { '★ ' + $item.Title } else { $item.Title })
    $row = New-Object System.Windows.Forms.ListViewItem($label)
    [void]$row.SubItems.Add($item.Buyer)
    [void]$row.SubItems.Add("$($item.Score)%")
    $daysText = 'Sin fecha'
    if ($item.Closing) {
      $remaining = ([datetime]$item.Closing - [datetime]::Now).TotalDays
      if ($remaining -lt 0) { $daysText = 'Vencido' } elseif ($remaining -lt 1) { $daysText = 'Hoy' } else { $daysText = "$([Math]::Ceiling($remaining)) días" }
      if ($remaining -ge 0 -and $remaining -le 3) { $row.BackColor = [Drawing.Color]::FromArgb(255,225,225) }
      elseif ($remaining -gt 3 -and $remaining -le 7) { $row.BackColor = [Drawing.Color]::FromArgb(255,246,211) }
      elseif ($remaining -gt 7) { $row.BackColor = [Drawing.Color]::FromArgb(232,247,237) }
    }
    [void]$row.SubItems.Add($daysText)
    [void]$row.SubItems.Add($(if ($item.Closing) { $item.Closing.ToString('dd/MM/yyyy HH:mm') } else { 'No informada' }))
    [void]$row.SubItems.Add($(if ($item.Department) { $item.Department } else { 'Consultar pliego' }))
    [void]$row.SubItems.Add($item.Source)
    $row.Tag = $item
    [void]$list.Items.Add($row)
  }
  $list.EndUpdate()
  $script:summary.Text = "$($visible.Count) coincidencias · $($script:allItems.Count) publicaciones recientes revisadas"
  Update-Details
}

function Update-Layout {
  $contentWidth = [Math]::Max(500, $main.ClientSize.Width - 44)
  $detailTop = [Math]::Max(260, $main.ClientSize.Height - 275)
  $list.Size = [System.Drawing.Size]::new($contentWidth, [Math]::Max(100, $detailTop - 136))
  $detail.Location = [System.Drawing.Point]::new(22, $detailTop)
  $detail.Size = [System.Drawing.Size]::new($contentWidth, 260)
  $refresh.Location = [System.Drawing.Point]::new([Math]::Max(250, $main.ClientSize.Width - 132), 26)
  $export.Location = [Drawing.Point]::new([Math]::Max(250, $main.ClientSize.Width - 272), 26)
  $sourcesButton.Location = [Drawing.Point]::new([Math]::Max(250, $main.ClientSize.Width - 412), 26)
}

function Refresh-Data {
  $refresh.Enabled = $false; $form.UseWaitCursor = $true
  try {
    $progress = { param($message) $script:statusLabel.Text = $message; [Windows.Forms.Application]::DoEvents() }
    $script:lastData = Get-AdonaiData $script:config $progress $true
    $script:allItems = @($script:lastData.Items)
    Apply-Filters
    $counts = $script:lastData.Counts
    $countText = "ARCE $($counts.ARCE) · ANTEL $($counts.ANTEL) + $($counts.'ANTEL/ARCE') en ARCE · UTE $($counts.UTE) · OSE $($counts.OSE)"
    if ($script:lastData.Failures.Count) { $script:statusLabel.Text = "Actualización parcial · $countText · Revisar: $($script:lastData.Failures -join ', ')" }
    else { $script:statusLabel.Text = "Publicaciones leídas: $countText · $(Get-Date -Format 'dd/MM/yyyy HH:mm')" }
    if (-not $script:allItems.Count) { [Windows.Forms.MessageBox]::Show('No se pudieron cargar llamados de las fuentes oficiales. Revisá tu conexión.', 'ADONAI Oportunidades', 'OK', 'Warning') | Out-Null }
    else { Show-AdonaiDeadlineAlerts }
  } catch {
    $script:statusLabel.Text = "No se pudo actualizar: $($_.Exception.Message)"
    [Windows.Forms.MessageBox]::Show("No se pudieron actualizar los llamados.`n`n$($_.Exception.Message)", 'ADONAI Oportunidades', 'OK', 'Warning') | Out-Null
  } finally {
    $refresh.Enabled = $true; $form.UseWaitCursor = $false
  }
}

$search.Add_TextChanged({ Apply-Filters })
$zone.Add_SelectedIndexChanged({ Apply-Filters })
$state.Add_SelectedIndexChanged({ Apply-Filters })
$sourceFilter.Add_SelectedIndexChanged({ Apply-Filters })
$services.Add_ItemCheck({ $form.BeginInvoke([Action]{ Apply-Filters }) | Out-Null })
$onlySaved.Add_CheckedChanged({ Apply-Filters })
$list.Add_SelectedIndexChanged({ Update-Details })
$refresh.Add_Click({ Refresh-Data })
$updateButton.Add_Click({ Check-ForUpdate })
$settingsButton.Add_Click({ Show-SettingsDialog })
$export.Add_Click({ Export-AdonaiCsv })
$sourcesButton.Add_Click({ Show-SourceStatus })
$open.Add_Click({ if ($list.SelectedItems.Count) { Start-Process $list.SelectedItems[0].Tag.Link } })
$portals.Add_Click({ $portalMenu.Show($portals, [System.Drawing.Point]::new(0, $portals.Height)) })
$save.Add_Click({
  if (-not $list.SelectedItems.Count) { return }
  $id = $list.SelectedItems[0].Tag.Id
  if ($script:saved.ContainsKey($id)) { $script:saved.Remove($id) } else { $script:saved[$id] = $true }
  Save-Saved; Apply-Filters
})
$trackingButton.Add_Click({ if ($list.SelectedItems.Count) { Show-TrackingDialog $list.SelectedItems[0].Tag } })
$analysisButton.Add_Click({ if ($list.SelectedItems.Count) { Show-AdonaiTenderAnalysisDialog $list.SelectedItems[0].Tag } })
$calendarButton.Add_Click({ if ($list.SelectedItems.Count) { Export-AdonaiCalendar $list.SelectedItems[0].Tag } })
$form.Add_Shown({
  $updateMarker = Join-Path $script:appDir 'actualizacion-ok.txt'
  if (Test-Path $updateMarker -PathType Leaf) {
    Remove-Item -LiteralPath $updateMarker -Force -ErrorAction SilentlyContinue
    [System.Windows.Forms.MessageBox]::Show(
      "La actualización se instaló correctamente.`n`nVersión $($script:appVersion.ToString())",
      'ADONAI Oportunidades', 'OK', 'Information'
    ) | Out-Null
  }
  Refresh-Data
})
$main.Add_Resize({ Update-Layout })
Load-Saved
Load-Tracking
[void]$form.PerformLayout()
Update-Layout
[void]$form.ShowDialog()
