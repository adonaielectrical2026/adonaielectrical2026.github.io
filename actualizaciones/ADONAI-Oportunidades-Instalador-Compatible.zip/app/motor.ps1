﻿$adonaiLocalData = [Environment]::GetFolderPath('LocalApplicationData')
if ([string]::IsNullOrWhiteSpace($adonaiLocalData)) { $adonaiLocalData = $env:LOCALAPPDATA }
if ([string]::IsNullOrWhiteSpace($adonaiLocalData)) { $adonaiLocalData = $env:TEMP }
if ([string]::IsNullOrWhiteSpace($adonaiLocalData)) { throw 'Windows no informó una carpeta local para guardar la configuración.' }
$global:AdonaiAppDir = Join-Path $adonaiLocalData 'AdonaiOportunidades'
$global:AdonaiConfigPath = Join-Path $global:AdonaiAppDir 'configuracion.json'
$global:AdonaiSentPath = Join-Path $global:AdonaiAppDir 'informe-enviados.json'
$global:AdonaiCachePath = Join-Path $global:AdonaiAppDir 'ultimos-resultados.json'
$global:AdonaiAlertPath = Join-Path $global:AdonaiAppDir 'alertas-vencimiento.json'
$global:AdonaiSourceUrl = 'https://www.comprasestatales.gub.uy/consultas/rss'
$global:AdonaiSourceSite = 'https://www.comprasestatales.gub.uy/consultas/'
$global:AdonaiUteUrl = 'https://portal.ute.com.uy/proveedores/compras/licitaciones'
$global:AdonaiOseUrl = 'https://www.ose.com.uy/compras-y-acreedores/llamados-programas-con-financiamiento-externo'
$global:AdonaiAntelUrl = 'https://antel.com.uy/institucional/compras-y-proveedores'
$global:AdonaiAntelDirectUrl = 'https://wse-prod.antel.com.uy/cpv/servlet/com.antel.cpi.hm0002vcpvil'

function Get-AdonaiDefaultCategories {
  return @(
    @{ Name = 'Instalaciones eléctricas'; Terms = @('instalacion electrica','instalaciones electricas','obra electrica','obras electricas','electrificacion','tendido electrico','cableado electrico','tablero electrico','tableros electricos','electricista','servicios electricos','montaje electrico') },
    @{ Name = 'Mantenimiento y reparación'; Terms = @('mantenimiento electrico','reparacion electrica','reacondicionamiento electrico','falla electrica','sistema electrico','mantenimiento de instalaciones') },
    @{ Name = 'Iluminación'; Terms = @('iluminacion de emergencia','luminaria de emergencia','alumbrado de emergencia','iluminacion','luminarias','alumbrado publico') },
    @{ Name = 'Cámaras de seguridad'; Terms = @('videovigilancia','camara de seguridad','camaras de seguridad','cctv','circuito cerrado','sistema de seguridad') },
    @{ Name = 'Trámites UTE'; Terms = @('tramite ute','habilitacion electrica','suministro electrico','potencia contratada','conexion electrica','nuevo suministro') }
  )
}

function New-AdonaiDefaultConfig {
  return [pscustomobject][ordered]@{
    IncludeTerms = @()
    ExcludeTerms = @()
    Email = [pscustomobject][ordered]@{
      Enabled = $false
      Recipients = @()
      Sender = ''
      SmtpServer = 'smtp.gmail.com'
      Port = 587
      UseSsl = $true
      AuthUser = ''
      PasswordEncrypted = ''
      SendTime = '08:00'
      SendWhenEmpty = $false
    }
    Alerts = [pscustomobject][ordered]@{
      Enabled = $true
      Days = @(7,3,1,0)
    }
  }
}

function Get-AdonaiConfig {
  $default = New-AdonaiDefaultConfig
  if (-not (Test-Path $global:AdonaiConfigPath -PathType Leaf)) { return $default }
  try {
    $stored = Get-Content -LiteralPath $global:AdonaiConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($stored.PSObject.Properties.Name -contains 'IncludeTerms') { $default.IncludeTerms = @($stored.IncludeTerms) }
    if ($stored.PSObject.Properties.Name -contains 'ExcludeTerms') { $default.ExcludeTerms = @($stored.ExcludeTerms) }
    if ($stored.PSObject.Properties.Name -contains 'Email' -and $null -ne $stored.Email) {
      foreach ($name in @('Enabled','Recipients','Sender','SmtpServer','Port','UseSsl','AuthUser','PasswordEncrypted','SendTime','SendWhenEmpty')) {
        if ($stored.Email.PSObject.Properties.Name -contains $name) { $default.Email.$name = $stored.Email.$name }
      }
      $default.Email.Recipients = @($default.Email.Recipients)
    }
    if ($stored.PSObject.Properties.Name -contains 'Alerts' -and $null -ne $stored.Alerts) {
      if ($stored.Alerts.PSObject.Properties.Name -contains 'Enabled') { $default.Alerts.Enabled = [bool]$stored.Alerts.Enabled }
      if ($stored.Alerts.PSObject.Properties.Name -contains 'Days') { $default.Alerts.Days = @($stored.Alerts.Days | ForEach-Object { [int]$_ }) }
    }
  } catch { }
  return $default
}

function Save-AdonaiConfig($config) {
  New-Item -ItemType Directory -Path $global:AdonaiAppDir -Force | Out-Null
  $config | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $global:AdonaiConfigPath -Encoding UTF8
}

function Protect-AdonaiPassword([string]$plainText) {
  if ([string]::IsNullOrEmpty($plainText)) { return '' }
  $secure = ConvertTo-SecureString -String $plainText -AsPlainText -Force
  return ConvertFrom-SecureString -SecureString $secure
}

function Unprotect-AdonaiPassword([string]$encrypted) {
  if ([string]::IsNullOrWhiteSpace($encrypted)) { return '' }
  $secure = ConvertTo-SecureString -String $encrypted
  $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
  try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
  finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
}

function Normalize-AdonaiText([string]$value) {
  if ($null -eq $value) { return '' }
  $decomposed = $value.Normalize([System.Text.NormalizationForm]::FormD)
  return ([regex]::Replace($decomposed, '\p{Mn}', '')).ToLowerInvariant()
}

function Get-AdonaiNodeText($node, [string]$name) {
  $child = $node.SelectSingleNode($name)
  if ($null -eq $child) { return '' }
  return [string]$child.InnerText
}

function Get-AdonaiUtf8ResponseText($response) {
  $stream = $response.RawContentStream
  if ($null -eq $stream) { throw 'La respuesta no contiene los bytes originales.' }
  if ($stream.CanSeek) { $stream.Position = 0 }
  $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8, $true)
  try { return $reader.ReadToEnd().TrimStart([char]0xFEFF) }
  finally { $reader.Dispose() }
}

function Invoke-AdonaiText([string]$url, [int]$timeout = 25) {
  [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
  $response = Invoke-WebRequest -Uri $url -UserAgent 'Mozilla/5.0 (ADONAI Oportunidades)' -UseBasicParsing -TimeoutSec $timeout
  return Get-AdonaiUtf8ResponseText $response
}

function Get-AdonaiDepartment([string]$value) {
  $text = ' ' + (Normalize-AdonaiText $value) + ' '
  $places = [ordered]@{
    'Artigas' = @('artigas','bella union'); 'Canelones' = @('canelones','las piedras','ciudad de la costa','pando','atlantida','santa lucia')
    'Cerro Largo' = @('cerro largo','melo','rio branco'); 'Colonia' = @('colonia','carmelo','nueva helvecia')
    'Durazno' = @('durazno','sarandi del yi'); 'Flores' = @('flores','trinidad'); 'Florida' = @('florida','sarandi grande')
    'Lavalleja' = @('lavalleja','minas'); 'Maldonado' = @('maldonado','punta del este','piriapolis'); 'Montevideo' = @('montevideo')
    'Paysandú' = @('paysandu'); 'Río Negro' = @('rio negro','fray bentos','young'); 'Rivera' = @('rivera','tranqueras')
    'Rocha' = @('rocha','chuy','lascano'); 'Salto' = @('salto'); 'San José' = @('san jose','ciudad del plata')
    'Soriano' = @('soriano','mercedes','dolores'); 'Tacuarembó' = @('tacuarembo','paso de los toros')
    'Treinta y Tres' = @('treinta y tres','vergara')
  }
  foreach ($department in $places.Keys) {
    foreach ($place in $places[$department]) {
      if ($text.Contains(' ' + $place + ' ')) { return $department }
    }
  }
  foreach ($marker in @('pereira rossell','planta de portland manga','18 de julio 1670','cerrito1034','cerrito 1034','paraguay 2097')) {
    if ($text.Contains($marker)) { return 'Montevideo' }
  }
  return ''
}

function Get-AdonaiMatchInfo([string]$content, $config) {
  $text = Normalize-AdonaiText $content
  foreach ($term in @($config.ExcludeTerms)) {
    $normalized = (Normalize-AdonaiText ([string]$term)).Trim()
    if ($normalized -and $text.Contains($normalized)) {
      return [pscustomobject]@{ Categories = @(); Terms = @(); Score = 0; Excluded = $true }
    }
  }
  $categories = @()
  $matches = @()
  foreach ($category in (Get-AdonaiDefaultCategories)) {
    $categoryMatched = $false
    foreach ($term in $category.Terms) {
      if ($text.Contains($term)) { $matches += $term; $categoryMatched = $true }
    }
    if ($categoryMatched) { $categories += $category.Name }
  }
  foreach ($term in @($config.IncludeTerms)) {
    $normalized = (Normalize-AdonaiText ([string]$term)).Trim()
    if ($normalized -and $text.Contains($normalized)) {
      $matches += [string]$term
      if ($categories -notcontains 'Palabras personalizadas') { $categories += 'Palabras personalizadas' }
    }
  }
  $matches = @($matches | Select-Object -Unique)
  $score = 0
  if ($categories.Count) { $score = [Math]::Min(99, 50 + ($categories.Count * 7) + ($matches.Count * 6)) }
  return [pscustomobject]@{ Categories = $categories; Terms = $matches; Score = $score; Excluded = $false }
}

function Add-AdonaiMatchInfo($record, $config) {
  $match = Get-AdonaiMatchInfo "$($record.Title) $($record.Description) $($record.Buyer)" $config
  $record | Add-Member -NotePropertyName Categories -NotePropertyValue @($match.Categories) -Force
  $record | Add-Member -NotePropertyName MatchedTerms -NotePropertyValue @($match.Terms) -Force
  $record | Add-Member -NotePropertyName Score -NotePropertyValue ([int]$match.Score) -Force
  $record | Add-Member -NotePropertyName Excluded -NotePropertyValue ([bool]$match.Excluded) -Force
  return $record
}

function ConvertFrom-AdonaiFeed([string]$content, $config) {
  [xml]$xml = $content
  $records = @()
  foreach ($entry in @($xml.SelectNodes('//item'))) {
    $parts = (Get-AdonaiNodeText $entry 'title') -split '\|', 2
    $title = $parts[0].Trim()
    $buyer = if ($parts.Count -gt 1) { $parts[1].Trim() } else { '' }
    $link = (Get-AdonaiNodeText $entry 'link').Trim() -replace '^http:', 'https:'
    if ($link -notmatch '^https://(www\.)?comprasestatales\.gub\.uy/') { continue }
    $raw = [System.Net.WebUtility]::HtmlDecode((Get-AdonaiNodeText $entry 'description'))
    $description = [regex]::Replace([regex]::Replace($raw, '<[^>]*>', ' '), '\s+', ' ').Trim()
    $closing = $null
    $deadline = [regex]::Match($description, 'Recepci[oó]n de ofertas hasta:\s*(\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2})\s*hs', 'IgnoreCase')
    if ($deadline.Success) {
      try { $closing = [datetime]::ParseExact($deadline.Groups[1].Value, 'dd/MM/yyyy HH:mm', [Globalization.CultureInfo]::InvariantCulture) } catch { }
      $description = $description.Substring(0, $deadline.Index).Trim()
    }
    $published = $null
    $pubText = (Get-AdonaiNodeText $entry 'pubDate') -replace '\s+\([^)]+\)$', ''
    try { $published = [datetimeoffset]::Parse($pubText, [Globalization.CultureInfo]::InvariantCulture).LocalDateTime } catch { }
    $source = if ((Normalize-AdonaiText $buyer) -match 'antel|telecomunicaciones') { 'ANTEL/ARCE' } else { 'ARCE' }
    $record = [pscustomobject]@{
      Id = $link; Title = $title; Buyer = $buyer; Description = $description; Department = (Get-AdonaiDepartment "$title $description $buyer")
      Closing = $closing; Published = $published; Link = $link; Source = $source; Categories = @(); MatchedTerms = @(); Score = 0; Excluded = $false
    }
    $records += Add-AdonaiMatchInfo $record $config
  }
  return $records
}

function Remove-AdonaiHtml([string]$value) {
  return [regex]::Replace([System.Net.WebUtility]::HtmlDecode([regex]::Replace($value, '<[^>]*>', ' ')), '\s+', ' ').Trim()
}

function Resolve-AdonaiOfficialLink([string]$base, [string]$rowHtml) {
  foreach ($match in [regex]::Matches($rowHtml, 'href\s*=\s*["'']([^"'']+)["'']', 'IgnoreCase')) {
    try {
      $url = New-Object uri([uri]$base, [System.Net.WebUtility]::HtmlDecode($match.Groups[1].Value))
      if ($url.Scheme -eq 'https' -and $url.Host -match '(^|\.)(gub\.uy|ute\.com\.uy|ose\.com\.uy|antel\.com\.uy)$') { return $url.AbsoluteUri }
    } catch { }
  }
  return $base
}

function ConvertFrom-AdonaiDirectTable([string]$content, [string]$base, [string]$sourceName, $config) {
  $records = @()
  $options = [Text.RegularExpressions.RegexOptions]::Singleline -bor [Text.RegularExpressions.RegexOptions]::IgnoreCase
  foreach ($row in [regex]::Matches($content, '<tr\b[^>]*>(.*?)</tr>', $options)) {
    $cells = @([regex]::Matches($row.Groups[1].Value, '<t[dh]\b[^>]*>(.*?)</t[dh]>', $options) | ForEach-Object { Remove-AdonaiHtml $_.Groups[1].Value })
    if ($cells.Count -lt 4) { continue }
    $reference = $cells[0]; $title = $cells[1]; $dateText = $cells[3]; $published = $null
    if ($sourceName -eq 'UTE') {
      if ($reference -eq 'DATA ROOM' -or $reference -match '^LICITACI') { continue }
    } else {
      try { $published = [datetime]::ParseExact($reference, 'dd/MM/yyyy', [Globalization.CultureInfo]::InvariantCulture) } catch { }
      if ($cells.Count -gt 4 -and $cells[4] -match 'Finalizado') { continue }
    }
    if ([string]::IsNullOrWhiteSpace($title)) { continue }
    $closing = $null
    $dateMatch = [regex]::Match($dateText, '(\d{2}/\d{2}/\d{4})(?:\s+(\d{2}:\d{2}))?')
    if ($dateMatch.Success) {
      $format = if ($dateMatch.Groups[2].Success) { 'dd/MM/yyyy HH:mm' } else { 'dd/MM/yyyy' }
      $value = if ($dateMatch.Groups[2].Success) { "$($dateMatch.Groups[1].Value) $($dateMatch.Groups[2].Value)" } else { $dateMatch.Groups[1].Value }
      try { $closing = [datetime]::ParseExact($value, $format, [Globalization.CultureInfo]::InvariantCulture) } catch { }
    }
    $record = [pscustomobject]@{
      Id = "$sourceName|$reference|$title"; Title = "$reference - $title"; Buyer = $sourceName; Description = $title
      Department = (Get-AdonaiDepartment $title); Closing = $closing; Published = $published
      Link = (Resolve-AdonaiOfficialLink $base $row.Groups[1].Value); Source = $sourceName
      Categories = @(); MatchedTerms = @(); Score = 0; Excluded = $false
    }
    $records += Add-AdonaiMatchInfo $record $config
  }
  return $records
}

function ConvertFrom-AdonaiAntelPortal([string]$content, $config) {
  $records = @()
  $options = [Text.RegularExpressions.RegexOptions]::Singleline -bor [Text.RegularExpressions.RegexOptions]::IgnoreCase
  foreach ($row in [regex]::Matches($content, '<tr\b[^>]*>(.*?)</tr>', $options)) {
    $cells = @([regex]::Matches($row.Groups[1].Value, '<t[dh]\b[^>]*>(.*?)</t[dh]>', $options) | ForEach-Object { Remove-AdonaiHtml $_.Groups[1].Value })
    if ($cells.Count -lt 2) { continue }
    $rowText = ([string]::Join(' · ', $cells)).Trim()
    $normalized = Normalize-AdonaiText $rowText
    if ($normalized -notmatch 'licit|compra|concurso|invitacion|objeto') { continue }
    $reference = [string]$cells[0]
    $title = @($cells | Where-Object { $_ -and $_.Length -gt 8 } | Sort-Object Length -Descending | Select-Object -First 1)
    if (-not $title.Count) { continue }
    $title = [string]$title[0]
    if ((Normalize-AdonaiText $title) -match 'numero.*objeto|fecha.*apertura') { continue }
    $closing = $null
    $dates = @([regex]::Matches($rowText, '(\d{2}/\d{2}/\d{4})(?:\s+(\d{2}:\d{2}))?'))
    if ($dates.Count) {
      $dateMatch = $dates[$dates.Count - 1]
      $format = if ($dateMatch.Groups[2].Success) { 'dd/MM/yyyy HH:mm' } else { 'dd/MM/yyyy' }
      $value = if ($dateMatch.Groups[2].Success) { "$($dateMatch.Groups[1].Value) $($dateMatch.Groups[2].Value)" } else { $dateMatch.Groups[1].Value }
      try { $closing = [datetime]::ParseExact($value, $format, [Globalization.CultureInfo]::InvariantCulture) } catch { }
    }
    $record = [pscustomobject]@{
      Id = "ANTEL|$reference|$title"; Title = "$reference - $title"; Buyer = 'ANTEL'; Description = $rowText
      Department = (Get-AdonaiDepartment $rowText); Closing = $closing; Published = $null
      Link = (Resolve-AdonaiOfficialLink $global:AdonaiAntelDirectUrl $row.Groups[1].Value); Source = 'ANTEL'
      Categories = @(); MatchedTerms = @(); Score = 0; Excluded = $false
    }
    $records += Add-AdonaiMatchInfo $record $config
  }
  return $records
}

function Get-AdonaiDuplicateKey($record) {
  $buyer = Normalize-AdonaiText ([string]$record.Buyer)
  if ($buyer -match 'usinas|\bute\b') { $buyer = 'ute' }
  elseif ($buyer -match 'telecomunicaciones|\bantel\b') { $buyer = 'antel' }
  elseif ($buyer -match 'obras sanitarias|\bose\b') { $buyer = 'ose' }
  $object = if ($record.Description) { [string]$record.Description } else { [string]$record.Title }
  $object = [regex]::Replace((Normalize-AdonaiText $object), '\s+', ' ').Trim()
  $closing = if ($record.Closing) { ([datetime]$record.Closing).ToString('yyyyMMddHHmm') } else { '' }
  return "$buyer|$object|$closing"
}

function Remove-AdonaiDuplicates([object[]]$records) {
  $ids = @{}; $keys = @{}; $result = @()
  foreach ($record in $records) {
    $linkKey = ([string]$record.Link).Split('?')[0].ToLowerInvariant()
    $semanticKey = Get-AdonaiDuplicateKey $record
    if ($ids.ContainsKey($linkKey)) { continue }
    if ($semanticKey.Length -gt 24 -and $keys.ContainsKey($semanticKey)) { continue }
    $ids[$linkKey] = $true
    if ($semanticKey.Length -gt 24) { $keys[$semanticKey] = $true }
    $result += $record
  }
  return $result
}

function Complete-AdonaiDepartments([object[]]$records, [scriptblock]$progress = $null) {
  $pending = @($records | Where-Object { $_.Source -match 'ARCE' -and $_.Score -gt 0 -and -not $_.Department } | Select-Object -First 35)
  $position = 0
  foreach ($item in $pending) {
    $position++
    if ($progress) { & $progress "Completando zonas desde ARCE ($position/$($pending.Count))…" }
    try {
      $detail = Remove-AdonaiHtml (Invoke-AdonaiText $item.Link 12)
      $department = Get-AdonaiDepartment "$($item.Title) $($item.Buyer) $($item.Description) $detail"
      if ($department) { $item.Department = $department }
    } catch { }
  }
}

function Get-AdonaiData($config = $null, [scriptblock]$progress = $null, [bool]$completeZones = $true) {
  if ($null -eq $config) { $config = Get-AdonaiConfig }
  $loaded = @(); $failures = @(); $counts = [ordered]@{ ARCE = 0; 'ANTEL/ARCE' = 0; ANTEL = 0; UTE = 0; OSE = 0 }
  try {
    if ($progress) { & $progress 'Consultando ARCE…' }
    $records = @(ConvertFrom-AdonaiFeed (Invoke-AdonaiText $global:AdonaiSourceUrl 25) $config)
    $counts.ARCE = @($records | Where-Object { $_.Source -eq 'ARCE' }).Count
    $counts.'ANTEL/ARCE' = @($records | Where-Object { $_.Source -eq 'ANTEL/ARCE' }).Count
    $loaded += $records
  } catch { $failures += 'ARCE' }
  foreach ($feed in @(@{ Name = 'UTE'; Url = $global:AdonaiUteUrl }, @{ Name = 'OSE'; Url = $global:AdonaiOseUrl })) {
    try {
      if ($progress) { & $progress "Consultando $($feed.Name)…" }
      $records = @(ConvertFrom-AdonaiDirectTable (Invoke-AdonaiText $feed.Url 22) $feed.Url $feed.Name $config)
      $counts[$feed.Name] = $records.Count; $loaded += $records
    } catch { $failures += $feed.Name }
  }
  try {
    if ($progress) { & $progress 'Consultando portal directo de ANTEL…' }
    $antelPage = Invoke-AdonaiText $global:AdonaiAntelUrl 15
    $antelDirect = Invoke-AdonaiText $global:AdonaiAntelDirectUrl 22
    $records = @(ConvertFrom-AdonaiAntelPortal $antelDirect $config)
    $counts.ANTEL = $records.Count; $loaded += $records
  } catch {
    if ([int]$counts.'ANTEL/ARCE' -eq 0) { $failures += 'ANTEL (portal directo)' }
  }
  $loaded = @(Remove-AdonaiDuplicates $loaded)
  if ($completeZones) { Complete-AdonaiDepartments $loaded $progress }
  $items = @($loaded | Sort-Object -Property @{ Expression = { if ($_.Closing) { $_.Closing } else { [datetime]::MaxValue } } })
  try {
    New-Item -ItemType Directory -Path $global:AdonaiAppDir -Force | Out-Null
    $items | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $global:AdonaiCachePath -Encoding UTF8
  } catch { }
  return [pscustomobject]@{ Items = $items; Counts = $counts; Failures = $failures; Updated = Get-Date }
}

function Get-AdonaiMatchExplanation($item) {
  $parts = @()
  $categories = @($item.Categories | Where-Object { $_ })
  $terms = @($item.MatchedTerms | Where-Object { $_ } | Select-Object -First 8)
  if ($categories.Count) { $parts += "Servicios relacionados: $($categories -join ', ')." }
  if ($terms.Count) { $parts += "Palabras detectadas: $($terms -join ', ')." }
  if ($item.Closing) {
    $hours = ([datetime]$item.Closing - [datetime]::Now).TotalHours
    if ($hours -lt 0) { $parts += 'La fecha informada ya venció; verificá si hubo una prórroga.' }
    elseif ($hours -le 24) { $parts += 'Prioridad urgente: cierra dentro de las próximas 24 horas.' }
    elseif ($hours -le 72) { $parts += 'Prioridad alta: quedan menos de 3 días.' }
    elseif ($hours -le 168) { $parts += 'Atención: cierra dentro de los próximos 7 días.' }
  } else { $parts += 'La fuente no informa el cierre en el listado; consultá el llamado oficial.' }
  if (-not $parts.Count) { return 'Coincidencia pendiente de revisión manual.' }
  return ($parts -join ' ')
}

function Get-AdonaiOfficialDocumentLinks([string]$html, [string]$baseUrl) {
  $links = @()
  foreach ($match in [regex]::Matches($html, 'href\s*=\s*["'']([^"'']+)["'']', 'IgnoreCase')) {
    try {
      $uri = New-Object uri([uri]$baseUrl, [System.Net.WebUtility]::HtmlDecode($match.Groups[1].Value))
      if ($uri.Scheme -ne 'https') { continue }
      if ($uri.Host -notmatch '(^|\.)(gub\.uy|ute\.com\.uy|ose\.com\.uy|antel\.com\.uy)$') { continue }
      $candidate = $uri.AbsoluteUri
      $normalized = Normalize-AdonaiText $candidate
      if ($normalized -match '\.pdf(?:$|\?)|pliego|documento|archivo|descarga') { $links += $candidate }
    } catch { }
  }
  return @($links | Select-Object -Unique | Select-Object -First 8)
}

function Get-AdonaiWordPdfText([string]$path, $word) {
  $document = $null
  try {
    $document = $word.Documents.Open($path, $false, $true, $false)
    return [string]$document.Content.Text
  } finally {
    if ($document) {
      $document.Close($false)
      [void][Runtime.InteropServices.Marshal]::ReleaseComObject($document)
    }
  }
}

function Get-AdonaiRequirementFindings([string]$text) {
  $definitions = @(
    @{ Name = 'Visita de obra'; Pattern = 'visita.{0,25}(obligatoria|obra|tecnica)|asistencia.{0,20}obligatoria' },
    @{ Name = 'Garantías'; Pattern = 'garant[ií]a.{0,45}(oferta|mantenimiento|cumplimiento|fiel)|dep[oó]sito de garant[ií]a' },
    @{ Name = 'RUPE y certificados'; Pattern = '\bRUPE\b|certificado.{0,25}(BPS|DGI)|estar al d[ií]a.{0,30}(BPS|DGI)' },
    @{ Name = 'Habilitación eléctrica'; Pattern = 'instalador.{0,30}(UTE|autorizado)|firma instaladora|habilitaci[oó]n.{0,25}(UTE|el[eé]ctrica)' },
    @{ Name = 'Antecedentes y experiencia'; Pattern = 'experiencia.{0,45}(m[ií]nima|comprobable|similar)|antecedentes.{0,35}(obra|servicio|empresa)' },
    @{ Name = 'Seguros y seguridad'; Pattern = 'seguro.{0,35}(accidente|responsabilidad|trabajo)|plan de seguridad|t[eé]cnico prevencionista' },
    @{ Name = 'Plazos'; Pattern = 'plazo.{0,35}(ejecuci[oó]n|entrega|obra)|fecha.{0,25}(apertura|l[ií]mite|visita)' }
  )
  $findings = @()
  foreach ($definition in $definitions) {
    $matches = @([regex]::Matches($text, $definition.Pattern, 'IgnoreCase'))
    if (-not $matches.Count) { continue }
    $examples = @()
    foreach ($match in $matches | Select-Object -First 2) {
      $start = [Math]::Max(0, $match.Index - 70)
      $length = [Math]::Min(230, $text.Length - $start)
      $snippet = [regex]::Replace($text.Substring($start, $length), '\s+', ' ').Trim()
      if ($snippet) { $examples += $snippet }
    }
    $findings += [pscustomobject]@{ Name = $definition.Name; Examples = @($examples | Select-Object -Unique) }
  }
  return $findings
}

function Get-AdonaiTenderAnalysis($item, [scriptblock]$progress = $null) {
  if ($progress) { & $progress 'Leyendo la publicación oficial…' }
  $html = Invoke-AdonaiText ([string]$item.Link) 30
  $cleanHtml = [regex]::Replace($html, '<(script|style)\b[^>]*>.*?</\1>', ' ', 'Singleline,IgnoreCase')
  $pageText = Remove-AdonaiHtml $cleanHtml
  $documentLinks = @(Get-AdonaiOfficialDocumentLinks $html ([string]$item.Link))
  $combinedText = "$($item.Title). $($item.Description). $pageText"
  $warnings = @()
  $word = $null
  if ($documentLinks.Count) {
    try {
      $word = New-Object -ComObject Word.Application
      $word.Visible = $false; $word.DisplayAlerts = 0
      $analysisDir = Join-Path ([IO.Path]::GetTempPath()) ('AdonaiAnalisis-' + [guid]::NewGuid().ToString('N'))
      New-Item -ItemType Directory -Path $analysisDir -Force | Out-Null
      $position = 0
      foreach ($documentUrl in $documentLinks | Select-Object -First 4) {
        $position++
        if ($progress) { & $progress "Leyendo documento $position de $([Math]::Min(4,$documentLinks.Count))…" }
        try {
          $filePath = Join-Path $analysisDir ("documento-$position.pdf")
          Invoke-WebRequest -Uri $documentUrl -UserAgent 'Mozilla/5.0 (ADONAI Oportunidades)' -UseBasicParsing -TimeoutSec 45 -OutFile $filePath
          if ((Get-Item -LiteralPath $filePath).Length -gt 100) { $combinedText += " " + (Get-AdonaiWordPdfText $filePath $word) }
        } catch { $warnings += "No se pudo leer automáticamente el documento $position." }
      }
    } catch {
      $warnings += 'Se encontraron documentos, pero Microsoft Word no está disponible para extraer el texto. Podés abrirlos desde la lista.'
    } finally {
      if ($word) {
        $word.Quit()
        [void][Runtime.InteropServices.Marshal]::ReleaseComObject($word)
      }
      if ($analysisDir -and (Test-Path $analysisDir)) { Remove-Item -LiteralPath $analysisDir -Recurse -Force -ErrorAction SilentlyContinue }
    }
  }
  if ($progress) { & $progress 'Detectando requisitos…' }
  $findings = @(Get-AdonaiRequirementFindings $combinedText)
  return [pscustomobject]@{
    Explanation = Get-AdonaiMatchExplanation $item
    Findings = $findings
    Documents = $documentLinks
    Warnings = $warnings
    PageCharacters = $pageText.Length
  }
}

function New-AdonaiBackup([string]$destination) {
  if ([string]::IsNullOrWhiteSpace($destination)) { throw 'Seleccioná dónde guardar la copia.' }
  $stage = Join-Path ([IO.Path]::GetTempPath()) ('AdonaiBackup-' + [guid]::NewGuid().ToString('N'))
  try {
    New-Item -ItemType Directory -Path $stage -Force | Out-Null
    $allowed = @('configuracion.json','guardados.json','seguimiento.json','informe-enviados.json','alertas-vencimiento.json','ultimos-resultados.json','informe-diario.log')
    foreach ($name in $allowed) {
      $source = Join-Path $global:AdonaiAppDir $name
      if (Test-Path $source -PathType Leaf) { Copy-Item -LiteralPath $source -Destination (Join-Path $stage $name) -Force }
    }
    [pscustomobject]@{ App = 'ADONAI Oportunidades'; Created = (Get-Date).ToString('o'); Version = '1.3.1' } |
      ConvertTo-Json | Set-Content -LiteralPath (Join-Path $stage 'respaldo.json') -Encoding UTF8
    if (Test-Path $destination) { Remove-Item -LiteralPath $destination -Force }
    Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $destination -CompressionLevel Optimal -Force
  } finally {
    if (Test-Path $stage) { Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue }
  }
}

function Restore-AdonaiBackup([string]$source) {
  if (-not (Test-Path $source -PathType Leaf)) { throw 'No se encontró la copia seleccionada.' }
  $stage = Join-Path ([IO.Path]::GetTempPath()) ('AdonaiRestore-' + [guid]::NewGuid().ToString('N'))
  try {
    Expand-Archive -LiteralPath $source -DestinationPath $stage -Force
    $metadata = Join-Path $stage 'respaldo.json'
    if (-not (Test-Path $metadata -PathType Leaf)) { throw 'El archivo no es una copia válida de ADONAI Oportunidades.' }
    New-Item -ItemType Directory -Path $global:AdonaiAppDir -Force | Out-Null
    $allowed = @('configuracion.json','guardados.json','seguimiento.json','informe-enviados.json','alertas-vencimiento.json','ultimos-resultados.json','informe-diario.log')
    foreach ($name in $allowed) {
      $file = Join-Path $stage $name
      if (Test-Path $file -PathType Leaf) { Copy-Item -LiteralPath $file -Destination (Join-Path $global:AdonaiAppDir $name) -Force }
    }
  } finally {
    if (Test-Path $stage) { Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue }
  }
}

function Test-AdonaiEmail([string]$value) {
  try { $null = New-Object System.Net.Mail.MailAddress($value); return $true } catch { return $false }
}

function Send-AdonaiMail($config, [object[]]$items, [bool]$isTest = $false) {
  $email = $config.Email
  $recipients = @($email.Recipients | Where-Object { Test-AdonaiEmail ([string]$_) })
  if (-not $recipients.Count) { throw 'Agregá al menos un correo destinatario válido.' }
  if ([string]::IsNullOrWhiteSpace([string]$email.Sender)) { throw 'Indicá el correo remitente.' }
  if ([string]::IsNullOrWhiteSpace([string]$email.SmtpServer)) { throw 'Indicá el servidor SMTP.' }
  $mail = New-Object System.Net.Mail.MailMessage
  $smtp = $null
  try {
    $mail.From = New-Object System.Net.Mail.MailAddress([string]$email.Sender, 'ADONAI ELECTRICAL')
    foreach ($recipient in $recipients) { [void]$mail.To.Add([string]$recipient) }
    $mail.SubjectEncoding = [Text.Encoding]::UTF8; $mail.BodyEncoding = [Text.Encoding]::UTF8; $mail.IsBodyHtml = $true
    $mail.Subject = if ($isTest) { 'ADONAI ELECTRICAL · Correo de prueba' } else { "ADONAI ELECTRICAL · Informe diario · $(Get-Date -Format 'dd/MM/yyyy')" }
    $rows = ''
    foreach ($item in @($items | Select-Object -First 50)) {
      $title = [System.Net.WebUtility]::HtmlEncode([string]$item.Title)
      $buyer = [System.Net.WebUtility]::HtmlEncode([string]$item.Buyer)
      $zone = if ($item.Department) { [System.Net.WebUtility]::HtmlEncode([string]$item.Department) } else { 'Consultar pliego' }
      $closing = if ($item.Closing) { ([datetime]$item.Closing).ToString('dd/MM/yyyy HH:mm') } else { 'No informada' }
      $link = [System.Net.WebUtility]::HtmlEncode([string]$item.Link)
      $urgency = ''
      if ($item.Closing) {
        $remaining = ([datetime]$item.Closing - [datetime]::Now).TotalDays
        if ($remaining -ge 0 -and $remaining -le 7) { $urgency = "<strong style='color:#b42318'> · VENCE PRONTO</strong>" }
      }
      $rows += "<tr><td style='padding:8px;border-bottom:1px solid #ddd'><a href='$link'>$title</a><br><small>$buyer · $zone · Cierre: $closing · Coincidencia: $($item.Score)%$urgency</small></td></tr>"
    }
    if (-not $rows) { $rows = "<tr><td style='padding:12px'>No se encontraron novedades ni vencimientos próximos.</td></tr>" }
    $intro = if ($isTest) { 'La configuración funciona correctamente.' } else { "El informe incluye $(@($items).Count) oportunidades relevantes y vencimientos en seguimiento." }
    $mail.Body = "<!doctype html><html><body style='font-family:Segoe UI,Arial;color:#172033'><h2 style='color:#10203a'>ADONAI ELECTRICAL</h2><p>$intro</p><table style='border-collapse:collapse;width:100%'>$rows</table><p style='color:#65758b;font-size:12px'>Informe generado por ADONAI Oportunidades. Verificá siempre el llamado y el pliego en el portal oficial.</p></body></html>"
    $smtp = New-Object System.Net.Mail.SmtpClient([string]$email.SmtpServer, [int]$email.Port)
    $smtp.EnableSsl = [bool]$email.UseSsl
    $user = if ($email.AuthUser) { [string]$email.AuthUser } else { [string]$email.Sender }
    $password = Unprotect-AdonaiPassword ([string]$email.PasswordEncrypted)
    if ($user -and $password) { $smtp.Credentials = New-Object System.Net.NetworkCredential($user, $password) }
    else { $smtp.UseDefaultCredentials = $true }
    $smtp.Send($mail)
  } finally {
    if ($smtp) { $smtp.Dispose() }
    $mail.Dispose()
  }
}
