@echo off
setlocal
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" (
  echo No se encontro Windows PowerShell.
  pause
  exit /b 1
)
"%PS%" -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0instalar.ps1"
if errorlevel 1 (
  echo.
  echo La instalacion no pudo completarse. Revise el mensaje mostrado.
  pause
)
endlocal
