@echo off
call "%~dp0app\Abrir ADONAI Oportunidades.cmd"
