﻿$ErrorActionPreference = 'Stop'
$tempDir = [IO.Path]::GetTempPath()
if ([string]::IsNullOrWhiteSpace($tempDir)) { $tempDir = $PSScriptRoot }
$logPath = Join-Path $tempDir 'ADONAI-Instalacion.log'

function Write-InstallLog([string]$message) {
  "$(Get-Date -Format 'dd/MM/yyyy HH:mm:ss') · $message" | Add-Content -LiteralPath $logPath -Encoding UTF8
}

try {
  Set-Content -LiteralPath $logPath -Value "Inicio de instalación de ADONAI Oportunidades" -Encoding UTF8
  $sourceDir = Join-Path $PSScriptRoot 'app'
  if (-not (Test-Path (Join-Path $sourceDir 'inicio.ps1') -PathType Leaf)) {
    throw 'Primero extraé completamente el ZIP. No ejecutes el instalador desde dentro del archivo comprimido.'
  }

  $localData = [Environment]::GetFolderPath('LocalApplicationData')
  if ([string]::IsNullOrWhiteSpace($localData)) { $localData = $env:LOCALAPPDATA }
  if ([string]::IsNullOrWhiteSpace($localData)) { throw 'Windows no informó la carpeta local de programas.' }
  $installDir = Join-Path $localData 'Programs\ADONAI Oportunidades'
  Write-InstallLog "Carpeta de destino: $installDir"
  New-Item -ItemType Directory -Path $installDir -Force | Out-Null
  Get-ChildItem -LiteralPath $sourceDir -File | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $installDir $_.Name) -Force
  }

  $uninstallCmd = @'
@echo off
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0desinstalar.ps1"
'@
  $uninstallCmd | Set-Content -LiteralPath (Join-Path $installDir 'Desinstalar ADONAI Oportunidades.cmd') -Encoding ASCII
  Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'desinstalar.ps1') -Destination (Join-Path $installDir 'desinstalar.ps1') -Force

  Write-InstallLog 'Creando accesos directos.'
  $shell = New-Object -ComObject WScript.Shell
  $desktop = [Environment]::GetFolderPath('Desktop')
  $programs = [Environment]::GetFolderPath('Programs')
  $startFolder = Join-Path $programs 'ADONAI ELECTRICAL'
  New-Item -ItemType Directory -Path $startFolder -Force | Out-Null
  $powerShellPath = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
  $startScript = Join-Path $installDir 'inicio.ps1'
  $launchArguments = "-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File `"$startScript`""
  $iconPath = Join-Path $installDir 'ADONAI Oportunidades.ico'
  foreach ($shortcutPath in @((Join-Path $desktop 'ADONAI Oportunidades.lnk'), (Join-Path $startFolder 'ADONAI Oportunidades.lnk'))) {
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $powerShellPath
    $shortcut.Arguments = $launchArguments
    $shortcut.WorkingDirectory = $installDir
    $shortcut.IconLocation = "$iconPath,0"
    $shortcut.Description = 'Buscador de licitaciones de ADONAI ELECTRICAL'
    $shortcut.Save()
  }

  Write-InstallLog 'Registrando desinstalador.'
  $uninstallKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\ADONAIOportunidades'
  New-Item -Path $uninstallKey -Force | Out-Null
  Set-ItemProperty -Path $uninstallKey -Name DisplayName -Value 'ADONAI Oportunidades'
  Set-ItemProperty -Path $uninstallKey -Name DisplayVersion -Value '1.3.1'
  Set-ItemProperty -Path $uninstallKey -Name Publisher -Value 'ADONAI ELECTRICAL'
  Set-ItemProperty -Path $uninstallKey -Name InstallLocation -Value $installDir
  Set-ItemProperty -Path $uninstallKey -Name DisplayIcon -Value $iconPath
  Set-ItemProperty -Path $uninstallKey -Name UninstallString -Value ('"' + (Join-Path $installDir 'Desinstalar ADONAI Oportunidades.cmd') + '"')
  New-ItemProperty -Path $uninstallKey -Name NoModify -PropertyType DWord -Value 1 -Force | Out-Null
  New-ItemProperty -Path $uninstallKey -Name NoRepair -PropertyType DWord -Value 1 -Force | Out-Null

  Write-InstallLog 'Abriendo la aplicación.'
  Start-Process -FilePath $powerShellPath -ArgumentList $launchArguments -WorkingDirectory $installDir -WindowStyle Hidden
  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.MessageBox]::Show(
    "ADONAI Oportunidades se instaló correctamente.`n`nEncontrarás el icono en el Escritorio y en el menú Inicio.",
    'Instalación terminada', 'OK', 'Information'
  ) | Out-Null
  Write-InstallLog 'Instalación terminada correctamente.'
  exit 0
} catch {
  Write-InstallLog "ERROR: $($_.Exception.Message)"
  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.MessageBox]::Show(
    "No se pudo instalar ADONAI Oportunidades.`n`n$($_.Exception.Message)`n`nRegistro:`n$logPath",
    'Error de instalación', 'OK', 'Error'
  ) | Out-Null
  exit 1
}
